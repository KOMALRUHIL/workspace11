from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from app.reset import DEFAULT_NEW_CASE_REFERENCE

SAMPLE_DATA_DIR = Path(__file__).resolve().parents[3] / "sample-data"


class ClaimPartyInput(BaseModel):
    role: str
    name: str | None = None
    insurer_name: str | None = None
    policy_number: str | None = None
    address: str | None = None


class ClaimVehicleInput(BaseModel):
    role: str
    registration: str | None = None
    vin: str | None = None
    make: str | None = None
    model: str | None = None
    variant: str | None = None
    manufacture_year: int | None = Field(default=None, ge=1886, le=2200)
    official_vehicle_class: str | None = Field(default=None, max_length=12)
    bodywork_code: str | None = Field(default=None, max_length=8)
    market_segment: str | None = Field(default=None, max_length=120)
    classification_source: str | None = Field(default=None, max_length=240)
    policy_number: str | None = None
    insurer_name: str | None = None
    damage_description: str | None = None

    @model_validator(mode="after")
    def classification_has_source(self):
        values = (self.official_vehicle_class, self.bodywork_code, self.market_segment)
        if any(values) and not (self.classification_source or "").strip():
            raise ValueError("Vehicle classification requires a source")
        return self


class VehicleClassificationRequest(BaseModel):
    registration: str = Field(min_length=1, max_length=32)
    official_vehicle_class: str | None = Field(default=None, max_length=12)
    bodywork_code: str | None = Field(default=None, max_length=8)
    market_segment: str | None = Field(default=None, max_length=120)
    classification_source: str = Field(min_length=3, max_length=240)
    verified_by: str = Field(min_length=1, max_length=160)


class ClaimCreateRequest(BaseModel):
    case_reference: str
    claim_number: str
    paying_insurer_name: str | None = None
    claiming_insurer_name: str | None = None
    third_party_name: str | None = None
    paying_policy_number: str | None = None
    claiming_policy_number: str | None = None
    accident_at: datetime | None = None
    accident_location: str | None = None
    accident_description: str | None = None
    damage_description: str | None = None
    created_by: str = "pilot.handler"
    notes: str | None = None
    parties: list[ClaimPartyInput] = Field(default_factory=list)
    vehicles: list[ClaimVehicleInput] = Field(default_factory=list)


class LiabilityDecisionRequest(BaseModel):
    status: str
    confirmed_by: str
    rationale: str
    split_liability_percentage: Decimal | None = Field(default=None, ge=0, le=100)

    @model_validator(mode="after")
    def split_requires_percentage(self):
        if self.status.replace(" ", "_").upper() == "SPLIT_LIABILITY":
            if self.split_liability_percentage is None:
                raise ValueError("Split liability requires a percentage.")
        return self


class InvoiceLineCorrectionRequest(BaseModel):
    actor: str
    reason: str
    raw_description: str | None = None
    item_kind: str | None = None
    part_number: str | None = None
    quantity: Decimal | None = None
    unit: str | None = None
    unit_price_net: Decimal | None = None
    line_total_net: Decimal | None = None
    vat_rate: Decimal | None = None
    vat_applicable: bool | None = None


class InvoiceLineManualCreateRequest(BaseModel):
    """A handler-entered line for a document the pipeline could not benchmark.

    Recorded with extraction_method=manual and confidence=1.0 so it flows into
    mapping and comparison on the next run, exactly like any other
    handler-approved extraction.
    """

    description: str = Field(min_length=1, max_length=2_000)
    quantity: Decimal | None = None
    unit: str | None = Field(default=None, max_length=80)
    unit_price_net: Decimal | None = None
    line_total_net: Decimal = Field(gt=0)
    vat_rate: Decimal | None = Field(default=None, ge=0, le=100)
    item_kind: str = Field(default="part", max_length=40)
    part_number: str | None = Field(default=None, max_length=160)
    page_number: int | None = Field(default=None, ge=1)
    recorded_by: str = Field(min_length=1, max_length=160)

    @model_validator(mode="after")
    def description_not_blank(self):
        if not self.description.strip():
            raise ValueError("description must not be blank")
        return self


class ExtractionDecisionRequest(BaseModel):
    decision: Literal["approved", "rejected", "undo"]
    actor: str = Field(min_length=1, max_length=160)
    reason: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def rejection_requires_reason(self):
        if self.decision == "rejected" and not (self.reason or "").strip():
            raise ValueError("Rejecting an extraction requires a reason.")
        return self


class PageCorrectionRequest(BaseModel):
    actor: str = Field(min_length=1, max_length=160)
    reason: str = Field(min_length=3, max_length=1000)
    page_type: str | None = None
    group_id: str | None = Field(default=None, max_length=120)
    rotation: int | None = None

    @model_validator(mode="after")
    def correction_is_explicit(self):
        correction_fields = {"page_type", "group_id", "rotation"} & self.model_fields_set
        if not correction_fields:
            raise ValueError(
                "Provide a page classification, group identifier or rotation correction."
            )
        if "page_type" in correction_fields and self.page_type is None:
            raise ValueError("Page classification cannot be null.")
        if "rotation" in correction_fields and self.rotation not in {0, 90, 180, 270}:
            raise ValueError("Rotation must be 0, 90, 180 or 270 degrees.")
        return self


class SettlementLineInput(BaseModel):
    line_item_id: str
    agreed_amount_net: Decimal = Field(ge=0)
    agreed_vat: Decimal | None = Field(default=None, ge=0)


class SettlementCreateRequest(BaseModel):
    agreed_amount_net: Decimal = Field(ge=0)
    agreed_vat: Decimal | None = Field(default=None, ge=0)
    agreed_at: datetime
    recorded_by: str
    note: str | None = None
    negotiation_reference: str | None = None
    lines: list[SettlementLineInput] = Field(default_factory=list)


class BundleComponentInput(BaseModel):
    ontology_item_id: str = Field(min_length=1)
    allocated_net: Decimal | None = Field(default=None, ge=0)
    quantity: Decimal | None = Field(default=None, gt=0)
    unit: str | None = None

    @model_validator(mode="after")
    def allocation_or_quantity_is_explicit(self):
        if self.allocated_net is None and self.quantity is None:
            raise ValueError("Each bundle component needs an explicit net allocation or quantity.")
        return self


class MappingDecisionRequest(BaseModel):
    actor: str = Field(min_length=1)
    ontology_item_id: str | None = None
    decision: str = Field(min_length=1)
    rationale: str = Field(min_length=1)
    bundle_components: list[BundleComponentInput] = Field(default_factory=list)


class AssessmentMappingOverrideRequest(BaseModel):
    """A handler's decision about which invoice one engineer assessment belongs to.

    ``reset`` is distinct from ``unlink``: it withdraws the instruction and
    hands the pairing back to the automatic rule, where ``unlink`` is an
    instruction the rule must not overturn on the next upload.
    """

    actor: str = Field(min_length=1, max_length=160)
    decision: Literal["link", "unlink", "reset"]
    invoice_id: str | None = Field(default=None, max_length=36)
    reason: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def link_requires_an_invoice(self):
        if self.decision == "link" and not (self.invoice_id or "").strip():
            raise ValueError("Linking requires the invoice to link to.")
        if self.decision != "link" and self.invoice_id:
            raise ValueError("Only a link decision carries an invoice.")
        return self


IntakeGroup = Literal["historical_claim", "in_house", "live"]


class MappingApprovalRequest(BaseModel):
    actor: str = Field(min_length=1, max_length=160)
    #: Omitted: the case-level approval, exactly as before.  Given: that
    #: upload source's own approval, which approves no other source.
    intake_group: IntakeGroup | None = None


class ChallengeLineAdjustment(BaseModel):
    line_id: str = Field(min_length=1, max_length=500)
    adjusted_challenge_amount: Decimal | None = None
    note: str | None = None


class ChallengeEmailRequest(BaseModel):
    invoice_id: str = Field(min_length=1, max_length=36)
    line_ids: list[str] = Field(min_length=1, max_length=500)
    recipient: str | None = Field(default=None, max_length=200)
    actor: str = Field(default="claims.handler", min_length=1, max_length=160)
    adjustments: list[ChallengeLineAdjustment] | None = None


class CreateStrategyThresholdRequest(BaseModel):
    item_name: str = Field(min_length=1, max_length=200)
    max_amount_net: Decimal = Field(ge=0)
    description: str = Field(default="", max_length=500)
    keywords: list[str] = Field(default_factory=list)


class UpdateStrategyThresholdRequest(BaseModel):
    item_name: str = Field(min_length=1, max_length=200)
    max_amount_net: Decimal = Field(ge=0)
    description: str = Field(default="", max_length=500)
    keywords: list[str] = Field(default_factory=list)


class ResearchTriggerRequest(BaseModel):
    requested_by: str
    note: str | None = None


class ResearchApprovalRequest(BaseModel):
    approved_by: str
    canonical_name: str
    item_type: str
    category: str
    unit: str
    price_net: Decimal = Field(gt=0)
    source_url_or_ref: str
    vehicle_applicability: str | None = None
    part_number: str | None = None
    rationale: str


class ManualResearchEvidenceRequest(BaseModel):
    source_uri: str
    title: str
    captured_at: datetime | None = None
    minimal_excerpt: str | None = None
    source_record_id: str | None = None
    price_net: Decimal | None = Field(default=None, ge=0)
    original_price: Decimal | None = Field(default=None, ge=0)
    currency: str = "GBP"
    vat_basis: str = "net"
    unit: str | None = None
    part_number: str | None = None
    fitment: dict[str, Any] | None = None
    quality_tier: str | None = None
    condition: str | None = None
    shipping: Decimal | None = Field(default=None, ge=0)
    stock_status: str | None = None


class ManualResearchSuggestionRequest(BaseModel):
    canonical_name: str
    item_type: str
    category: str
    unit: str
    price_net: Decimal = Field(ge=0)
    date_checked: date
    rationale: str
    vat_basis: str = "net"
    price_scope: str = "unit"
    part_number: str | None = None
    vehicle_compatibility: dict[str, Any] | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)
    currency: str = "GBP"
    region: str = "UK"
    quality_tier: str | None = None


class ManualResearchRequest(BaseModel):
    requested_by: str
    query_text: str
    suggestion: ManualResearchSuggestionRequest
    evidence: list[ManualResearchEvidenceRequest] = Field(min_length=1)
    source_allow_list_version: str = "pilot-manual-sources-v1"


class ResearchItemApprovalRequest(BaseModel):
    approved_by: str
    reviewer_note: str | None = None


class SeedImportRequest(BaseModel):
    ontology_path: str = str(SAMPLE_DATA_DIR / "ontology_seed.xlsx")
    historical_path: str = str(SAMPLE_DATA_DIR / "historical_claims_seed.xlsx")
    adapter_key: str = "excel_seed"


class ReviewDecisionRequest(BaseModel):
    actor: str
    approved: bool = True
    rationale: str
    challenge_price_net: Decimal | None = Field(default=None, ge=0)


class FinaliseCaseRequest(BaseModel):
    finalised_by: str
    note: str | None = None


class ReprocessCaseRequest(BaseModel):
    actor: str = Field(min_length=1)
    ontology_version_id: str | None = None


class CaseDataResetRequest(BaseModel):
    """Guarded request body for the destructive clean-slate reset.

    ``confirm`` carries no default on purpose: the reset must never be a
    zero-argument call that a stray click or a replayed request can trigger.
    """

    confirm: str = Field(description='Must be exactly "DELETE ALL CASE DATA".')
    new_case_reference: str | None = Field(default=DEFAULT_NEW_CASE_REFERENCE, max_length=120)
    purge_derived_history: bool = True
    actor: str = Field(default="claimguard.reset", min_length=1, max_length=160)
