import { useEffect, useState } from "react"
import {
  AlertCircleIcon,
  CheckCircle2Icon,
  MailIcon,
} from "lucide-react"
import { toast } from "sonner"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

import {
  benchmarkCellState,
  challengePriceTotal,
  challengeSummary,
  documentOrder,
  generatedByLabel,
  isChallenge,
  lowLineDistance,
  mailtoHref,
  money,
  observationsLabel,
  toNumber,
} from "./benchmark-analysis-rows"
import {
  draftChallengeEmail,
  fetchBenchmarkAnalysis,
  type AnalysisBenchmark,
  type AnalysisLine,
  type BenchmarkAnalysisPayload,
  type BenchmarkEvidenceRow,
  type BenchmarkSource,
  type ChallengeEmailDraft,
  type ChallengeLevel,
  type ChallengeLineAdjustmentInput,
} from "./benchmark-api"
import {
  InvoiceDocumentPreviewDialog,
  OriginBadge,
  SourceEvidenceModal,
  VehicleCategoryBadge,
} from "./benchmark-evidence"
import { documentApiErrorMessage } from "./document-api"
import { Metric, ScreenHeading } from "./shared"

export type AnalysisSort = "document" | "level"

function LevelBadge({
  level,
  rationale,
}: {
  level: ChallengeLevel | null
  rationale?: string
}) {
  if (!level) return <span className="text-muted-foreground">—</span>
  if (level === "high") {
    const tooltipText = rationale || "High Priority: Exceeds multiple benchmarks significantly."
    return (
      <Badge
        variant="destructive"
        className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] px-2.5 py-0.5 shadow-sm uppercase tracking-wider cursor-help transition-transform hover:scale-105"
        title={tooltipText}
      >
        High
      </Badge>
    )
  }
  if (level === "medium") {
    const tooltipText = rationale || "Medium Priority: Rate exceeds benchmark threshold."
    return (
      <Badge
        className="bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] px-2.5 py-0.5 shadow-sm uppercase tracking-wider border-transparent cursor-help transition-transform hover:scale-105"
        title={tooltipText}
      >
        Medium
      </Badge>
    )
  }
  const tooltipText = rationale || "Low Priority: Minor variance within tolerance."
  return (
    <Badge
      variant="outline"
      className="border-sky-400 text-sky-800 dark:text-sky-300 bg-sky-100/80 dark:bg-sky-950/40 font-bold text-[11px] px-2.5 py-0.5 uppercase tracking-wider cursor-help transition-transform hover:scale-105"
      title={tooltipText}
    >
      Low
    </Badge>
  )
}

/** One benchmark's cell. Red when the line violates it, amber when the line
 * is above it but inside the rule, and "No data" -- never £0.00 -- when the
 * source holds nothing for this repair item in this category. `n` sits
 * beside every P90. Clickable to open a dedicated evidence pop-up window. */
function BenchmarkCell({
  benchmark,
  onClick,
}: {
  benchmark: AnalysisBenchmark
  onClick?: () => void
}) {
  const state = benchmarkCellState(benchmark)
  const isInteractive = state !== "no-data" && Boolean(onClick)
  return (
    <TableCell
      data-benchmark-state={state}
      onClick={isInteractive ? onClick : undefined}
      className={cn(
        "text-right tabular-nums",
        isInteractive && "cursor-pointer hover:underline transition-colors",
        state === "violated" && "font-semibold text-destructive",
        state === "above" && "font-medium text-amber-700 dark:text-amber-400"
      )}
      title={isInteractive ? "Click to open historical benchmark evidence popup" : undefined}
    >
      {state === "no-data" ? (
        <span className="text-muted-foreground">No data</span>
      ) : (
        <div className="flex flex-col items-end gap-0.5"><div><span className="font-medium">{money(benchmark.p90)}</span> <span className="text-xs opacity-80">{observationsLabel(benchmark.observations)}</span></div>{toNumber(benchmark.difference_pct) != null && (state === "violated" || state === "above") ? (<div><span className={cn("inline-block rounded px-1.5 py-0.2 text-[10px] font-bold", state === "violated" ? "bg-rose-200/80 text-rose-900 dark:bg-rose-900/60 dark:text-rose-200" : "bg-amber-200/80 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200")}>+{benchmark.difference_pct}% over</span></div>) : null}</div>
      )}
    </TableCell>
  )
}

function ChallengeAmountCell({
  line,
  approved,
}: {
  line: AnalysisLine
  approved?: { amount: string; note: string }
}) {
  const isChallenged = isChallenge(line) || Boolean(approved)
  const isLow = line.challenge.level === "low"

  if (isChallenged) {
    const effectiveAmount = approved?.amount ?? line.challenge.challenge_amount
    const invoicedAmt = toNumber(line.amount) ?? 0
    const reductionAmt = toNumber(effectiveAmount) ?? 0
    const justifiedAmt = Math.max(0, invoicedAmt - reductionAmt).toFixed(2)

    return (
      <TableCell className="text-right tabular-nums">
        <div className="flex flex-col items-end gap-0.5 whitespace-nowrap">
          <span className="font-semibold text-rose-700 dark:text-rose-400">
            {money(effectiveAmount)}
          </span>
          <span className="text-xs text-muted-foreground">
            Justified {money(justifiedAmt)}
          </span>
        </div>
      </TableCell>
    )
  }

  if (isLow) {
    const distance = lowLineDistance(line)
    const invoicedAmt = toNumber(line.amount) ?? 0
    const challengeAmt =
      distance != null
        ? distance.toFixed(2)
        : line.challenge.challenge_amount !== "0.00"
          ? line.challenge.challenge_amount
          : null
    const reductionAmt = toNumber(challengeAmt) ?? 0
    const justifiedAmt =
      line.challenge.justified_amount ??
      (distance != null
        ? (invoicedAmt - distance).toFixed(2)
        : invoicedAmt.toFixed(2))

    if (challengeAmt && reductionAmt > 0) {
      return (
        <TableCell className="text-right tabular-nums">
          <div className="flex flex-col items-end gap-0.5 whitespace-nowrap">
            <span className="font-medium text-sky-800 dark:text-sky-300">
              {money(challengeAmt)}
            </span>
            <span className="text-xs text-muted-foreground">
              Justified {money(justifiedAmt)}
            </span>
          </div>
        </TableCell>
      )
    }
  }

  return (
    <TableCell className="text-right text-muted-foreground">—</TableCell>
  )
}

/** Interactive dialog to preview, edit, and approve or review a benchmark line */
export function ChallengeApprovalDialog({
  line,
  open,
  onOpenChange,
  onApprove,
  existingApproval,
}: {
  line: AnalysisLine | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onApprove: (lineId: string, amount: string, note: string, draftNow?: boolean) => void
  existingApproval?: { amount: string; note: string }
}) {
  if (!line) return null
  const isLow = line.challenge.level === "low"
  const defaultAmount =
    existingApproval?.amount ??
    (line.challenge.challenge_amount !== "0.00"
      ? line.challenge.challenge_amount
      : lowLineDistance(line) != null
        ? lowLineDistance(line)!.toFixed(2)
        : line.amount) ??
    ""
  const defaultNote = existingApproval?.note ?? ""
  const [challengeAmount, setChallengeAmount] = useState(defaultAmount)
  const [note, setNote] = useState(defaultNote)
  const [showOverrideForm, setShowOverrideForm] = useState(Boolean(existingApproval))

  useEffect(() => {
    if (line) {
      setChallengeAmount(
        existingApproval?.amount ??
          (line.challenge.challenge_amount !== "0.00"
            ? line.challenge.challenge_amount
            : lowLineDistance(line) != null
              ? lowLineDistance(line)!.toFixed(2)
              : line.amount) ??
          ""
      )
      setNote(existingApproval?.note ?? "")
      setShowOverrideForm(Boolean(existingApproval))
    }
  }, [line, existingApproval])

  const linePrice = parseFloat(line.amount || "0")
  const numChallenge = parseFloat(challengeAmount || "0")
  const netJustified = isNaN(linePrice) || isNaN(numChallenge) ? 0 : Math.max(0, linePrice - numChallenge)

  const handleSubmit = (draftNow = false) => {
    const parsed = parseFloat(challengeAmount)
    if (isNaN(parsed) || parsed <= 0) {
      toast.error("Please enter a valid challenge reduction amount greater than £0.00.")
      return
    }
    if (parsed > linePrice) {
      toast.error("Challenge reduction amount cannot exceed the total invoiced item price.")
      return
    }
    onApprove(line.line_id, parsed.toFixed(2), note.trim(), draftNow)
    toast.success(`Challenge approved for ${line.description}`, {
      description: `Reduction of ${money(parsed.toFixed(2))} confirmed (justified price ${money(netJustified.toFixed(2))}).`,
    })
    onOpenChange(false)
  }

  const handleResetToSystem = () => {
    setChallengeAmount(line.challenge.challenge_amount || "0.00")
    setNote("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <DialogTitle>
              {isLow && !showOverrideForm ? "Benchmark Item Review" : "Preview & Approve Challenge"}
            </DialogTitle>
            <LevelBadge level={line.challenge.level} />
          </div>
          <DialogDescription>
            {isLow && !showOverrideForm
              ? "Review benchmark comparison and policy tolerance details for this item."
              : "Review benchmark evidence, adjust challenge reduction if required, and approve line."}
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border bg-muted/30 p-3 space-y-2 text-sm">
          <div className="flex justify-between font-medium">
            <span>Item: {line.description}</span>
            <OriginBadge origin={line.origin} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground pt-1">
            <div>
              <span className="font-semibold text-foreground">Invoiced Item Price:</span>{" "}
              {money(line.amount)}
            </div>
            <div>
              <span className="font-semibold text-foreground">Benchmark Justified Price:</span>{" "}
              {money(line.challenge.justified_amount)}
            </div>
          </div>
          <div className="text-xs text-muted-foreground pt-1">
            <span className="font-semibold text-foreground">Benchmark Evidence & Rule:</span>
            <p className="mt-0.5">{line.challenge.reason}</p>
          </div>
        </div>

        {isLow && !showOverrideForm ? (
          <div className="space-y-3 pt-2">
            <div className="rounded-md border border-amber-300 bg-amber-50/50 p-3 text-xs text-amber-900 dark:border-amber-900 dark:bg-amber-950/20 dark:text-amber-300">
              <p className="font-semibold">Why this item is not automatically challenged:</p>
              <p className="mt-1 leading-relaxed">
                The price is {money(lowLineDistance(line))} above the blended benchmark P90, which is within the insurer&apos;s allowable policy tolerance threshold (e.g. less than 10% threshold / minimum dispute rule).
              </p>
            </div>
            <div className="flex flex-wrap justify-between items-center gap-2 pt-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-foreground"
                onClick={() => setShowOverrideForm(true)}
              >
                Challenge anyway (manual override)
              </Button>
              <Button type="button" onClick={() => onOpenChange(false)}>
                Close
              </Button>
            </div>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSubmit(false)
            }}
            className="space-y-4 pt-2"
          >
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-sm font-medium">
                <label htmlFor="challenge-amount">Challenge Reduction Amount (£) *</label>
                {line.challenge.challenge_amount !== "0.00" ? (
                  <button
                    type="button"
                    onClick={handleResetToSystem}
                    className="text-xs text-primary hover:underline"
                  >
                    Reset to system ({money(line.challenge.challenge_amount)})
                  </button>
                ) : null}
              </div>
              <Input
                id="challenge-amount"
                type="number"
                step="0.01"
                min="0.01"
                max={line.amount}
                value={challengeAmount}
                onChange={(e) => setChallengeAmount(e.target.value)}
                required
                className="text-base font-semibold"
              />
              <p className="text-xs text-muted-foreground">
                Adjusted proposed justified price:{" "}
                <span className="font-semibold text-foreground">{money(netJustified.toFixed(2))}</span>
              </p>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="challenge-note" className="text-sm font-medium">
                Handler Dispute Rationale / Note (Optional)
              </label>
              <Textarea
                id="challenge-note"
                placeholder="e.g. Capped per insurer policy threshold; excess repair charges disallowed."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="h-20 resize-none text-xs"
              />
            </div>

            <div className="flex flex-wrap justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => handleSubmit(true)}
              >
                Approve & Draft Email
              </Button>
              <Button type="submit">
                Approve Challenge
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}


/** The analysis itself, rendered from a payload so it can be tested without
 * a network. The `initial*` props seed the local state for the same reason:
 * a server render has no pointer to click the sort, a checkbox or a toggle. */
export function BenchmarkAnalysisView({
  analysis,
  onSelectInvoice,
  onDraftEmail,
  drafting,
  initialFilter = "all",
  initialSelected = [],
}: {
  analysis: BenchmarkAnalysisPayload
  caseReference?: string
  onThresholdsChanged?: () => void
  onOpenStrategyThresholds?: () => void
  onSelectInvoice: (invoiceId: string) => void
  onDraftEmail: (lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) => void
  drafting: boolean
  initialSort?: AnalysisSort
  initialFilter?: "all" | "challenges"
  initialSelected?: string[]
  initialEvidenceOpen?: string[]
}) {
  const [filter, setFilter] = useState<"all" | "challenges">(initialFilter)
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initialSelected)
  )
  const [inspectingSource, setInspectingSource] = useState<{
    line: AnalysisLine
    source: BenchmarkSource
  } | null>(null)
  const [inspectingRow, setInspectingRow] = useState<BenchmarkEvidenceRow | null>(
    null
  )
  const [approvingLine, setApprovingLine] = useState<AnalysisLine | null>(null)
  const [approvedChallenges, setApprovedChallenges] = useState<
    Map<string, { amount: string; note: string }>
  >(new Map())

  const { invoice } = analysis
  const lines = documentOrder(analysis.lines)
  const summary = challengeSummary(analysis.lines)
  const challengeLines = lines.filter((l) => isChallenge(l) || approvedChallenges.has(l.line_id))
  const displayedLines = filter === "challenges" ? challengeLines : lines
  const selectedIds = lines
    .filter(
      (line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id))
    )
    .map((line) => line.line_id)
  const selectedTotal = lines
    .filter((line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id)))
    .reduce((total, line) => {
      const approved = approvedChallenges.get(line.line_id)
      const amt = approved ? toNumber(approved.amount) : toNumber(line.challenge.challenge_amount)
      return total + (amt ?? 0)
    }, 0)

  function handleApproveChallenge(
    lineId: string,
    amount: string,
    note: string,
    draftNow = false
  ) {
    const nextApproved = new Map(approvedChallenges)
    nextApproved.set(lineId, { amount, note })
    setApprovedChallenges(nextApproved)

    const nextSelected = new Set(selected)
    nextSelected.add(lineId)
    setSelected(nextSelected)

    if (draftNow) {
      const activeIds = Array.from(nextSelected)
      const adjustments: ChallengeLineAdjustmentInput[] = activeIds.map((id) => ({
        line_id: id,
        adjusted_challenge_amount: nextApproved.get(id)?.amount,
        note: nextApproved.get(id)?.note,
      }))
      onDraftEmail(activeIds, adjustments)
    }
  }

  const handleDraftClick = () => {
    const adjustments: ChallengeLineAdjustmentInput[] = selectedIds.map((id) => ({
      line_id: id,
      adjusted_challenge_amount: approvedChallenges.get(id)?.amount,
      note: approvedChallenges.get(id)?.note,
    }))
    onDraftEmail(selectedIds, adjustments)
  }

  const vehicle =
    [invoice.vehicle_make, invoice.vehicle_model].filter(Boolean).join(" ") ||
    "Not printed"

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>
                Invoice {invoice.invoice_number ?? "number not printed"}
              </CardTitle>
              <CardDescription>
                Every line of this invoice, then every line of its engineer
                assessment, benchmarked across independent reference sources.
              </CardDescription>
            </div>
            {analysis.live_invoices.length > 1 ? (
              <select
                className="h-9 min-w-56 rounded-md border bg-background px-3 text-sm"
                aria-label="New invoice to analyse"
                value={invoice.id}
                onChange={(event) => onSelectInvoice(event.target.value)}
              >
                {analysis.live_invoices.map((option) => (
                  <option key={option.id} value={option.id}>
                    {[option.invoice_number ?? "Number not printed", option.registration]
                      .filter(Boolean)
                      .join(" · ")}
                  </option>
                ))}
              </select>
            ) : null}
          </div>
        </CardHeader>
        <CardContent>
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle</dt>
              <dd className="font-medium">{vehicle}</dd>
              <dd className="text-muted-foreground">
                {invoice.registration ?? "Registration not printed"}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle category</dt>
              <dd className="mt-1">
                <VehicleCategoryBadge
                  category={invoice.vehicle_category}
                  source={invoice.vehicle_category_source}
                />
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">
                Paired engineer assessment
              </dt>
              <dd className="font-medium">
                {invoice.paired_assessment_number ?? (
                  <span className="font-normal text-muted-foreground">
                    No engineer assessment paired
                  </span>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Valuation rule</dt>
              <dd className="text-muted-foreground">
                Challenge when over the benchmark price by more than {analysis.threshold_pct}%
                and by at least {money(analysis.minimum_challenge_amount)}.
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Metric
            label="Total deviation from benchmark"
            value={money(challengePriceTotal(analysis.lines))}
            hint="Sum of proposed benchmark prices for this invoice's High and Medium lines only; excludes unchanged lines."
          />
          <Metric
            label="Total challenge amount"
            value={money(summary.total)}
            hint="Reduction requested on High and Medium lines only. Low lines are shown, never counted."
            emphasis={summary.total > 0}
          />
          <div className="min-w-0 px-1 py-1">
            <p className="text-xs font-medium text-muted-foreground">
              Challenges by level
            </p>
            <p className="mt-2 flex flex-wrap items-center gap-2 text-sm">
              <Badge variant="destructive" className="font-semibold">{summary.counts.high} high</Badge>
              <Badge className="bg-amber-500 hover:bg-amber-600 text-white border-transparent font-semibold">{summary.counts.medium} medium</Badge>
              <Badge
                variant="outline"
                className="border-sky-400 text-sky-800 dark:text-sky-300 bg-sky-50/60 dark:bg-sky-950/30 font-semibold"
              >
                {summary.counts.low} low
              </Badge>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              High: all benchmarks violated. Medium: partially violated. Low: within tolerance.
            </p>
          </div>
          <Metric
            label="Approved & queued for email"
            value={money(selectedTotal)}
            hint={`${selectedIds.length} of ${challengeLines.length} challenges selected`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle>Line items against benchmarks</CardTitle>
              <CardDescription>
                Click any benchmark figure or percentage to view contributing historical evidence in a pop-up window. Click Challenge to preview, edit, and approve dispute amounts.
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex rounded-md border p-0.5" role="group" aria-label="Filter lines">
                <Button
                  size="sm"
                  variant={filter === "all" ? "secondary" : "ghost"}
                  aria-pressed={filter === "all"}
                  onClick={() => setFilter("all")}
                >
                  All lines
                </Button>
                <Button
                  size="sm"
                  variant={filter === "challenges" ? "secondary" : "ghost"}
                  aria-pressed={filter === "challenges"}
                  onClick={() => setFilter("challenges")}
                >
                  All challenges
                </Button>
              </div>
              <Button
                size="sm"
                variant="outline"
                disabled={!challengeLines.length}
                onClick={() => {
                  if (selectedIds.length === challengeLines.length) {
                    setSelected(new Set())
                  } else {
                    const next = new Set(challengeLines.map((line) => line.line_id))
                    setSelected(next)
                  }
                }}
              >
                {challengeLines.length &&
                selectedIds.length === challengeLines.length
                  ? "Clear selection"
                  : "Select all challenges"}
              </Button>
              <Button
                size="sm"
                disabled={!selectedIds.length || drafting}
                onClick={handleDraftClick}
              >
                {drafting ? "Drafting…" : `Draft email (${selectedIds.length})`}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div data-testid="analysis-table" className="rounded-lg border overflow-x-auto">
            <Table className="w-full table-fixed text-xs [&_th]:h-auto [&_th]:py-2.5 [&_th]:px-1.5 [&_th]:whitespace-normal [&_td]:py-2 [&_td]:px-1.5">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[8%]">Vehicle category</TableHead>
                  <TableHead className="w-[18%]">Description</TableHead>
                  <TableHead className="w-[7%] text-right font-semibold text-foreground">
                    Item price
                  </TableHead>
                  <TableHead className="w-[10%] text-right">
                    Third-party P90 (n)
                  </TableHead>
                  <TableHead className="w-[10%] text-right">In-house P90 (n)</TableHead>
                  <TableHead className="w-[10%] text-right">Same insurer P90 (n)</TableHead>
                  <TableHead className="w-[11%] text-right">Strategy policy threshold (n)</TableHead>
                  <TableHead className="w-[7%] text-center">Challenge level</TableHead>
                  <TableHead className="w-[12%] text-right">Challenge amount</TableHead>
                  <TableHead className="w-[7%] text-center">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayedLines.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={10} className="whitespace-normal py-8 text-center text-muted-foreground">
                      {filter === "challenges"
                        ? "No challenged line items found for this invoice."
                        : "No item prices are available to compare. Review this invoice in Document intelligence."}
                    </TableCell>
                  </TableRow>
                )}
                {displayedLines.map((line) => {
                  const isApproved = approvedChallenges.has(line.line_id)
                  const isChallenged = isChallenge(line) || isApproved

                  return (
                    <TableRow
                      key={line.line_id}
                      data-line-id={line.line_id}
                      data-level={line.challenge.level ?? "none"}
                      className={cn(
                        "transition-all duration-150",
                        line.challenge.level === "high" &&
                          "border-l-[5px] border-l-rose-500 bg-rose-50/50 hover:bg-rose-100/70 dark:bg-rose-950/20 dark:hover:bg-rose-950/40",
                        line.challenge.level === "medium" &&
                          "border-l-[5px] border-l-amber-500 bg-amber-50/50 hover:bg-amber-100/70 dark:bg-amber-950/20 dark:hover:bg-amber-950/40",
                        line.challenge.level === "low" &&
                          "border-l-[5px] border-l-sky-400 bg-sky-50/40 hover:bg-sky-100/60 dark:bg-sky-950/15 dark:hover:bg-sky-950/30",
                        (!line.challenge.level || line.challenge.level === "none") &&
                          "border-l-[5px] border-l-transparent hover:bg-muted/40"
                      )}
                    >
                      {/* 1. Vehicle category */}
                      <TableCell className="align-top py-3">
                        <VehicleCategoryBadge
                          category={invoice.vehicle_category}
                          source={invoice.vehicle_category_source}
                        />
                      </TableCell>

                      {/* 2. Description */}
                      <TableCell className="whitespace-normal [overflow-wrap:anywhere]">
                        <span className="font-medium">{line.description}</span>
                        <span className="mt-1 flex flex-wrap items-center gap-1.5">
                          <OriginBadge origin={line.origin} />
                          {line.is_duplicate || line.challenge.is_duplicate ? (
                            <Badge
                              variant="destructive"
                              className="px-1.5 py-0 text-[10px] font-semibold"
                            >
                              Duplicate charge
                            </Badge>
                          ) : null}
                          {line.repair_item ? (
                            <span className="text-xs text-muted-foreground">
                              {line.repair_item}
                            </span>
                          ) : null}
                        </span>
                      </TableCell>

                      {/* 3. New Invoice Item Price */}
                      <TableCell className="text-right tabular-nums font-semibold text-foreground">
                        {money(line.amount)}
                      </TableCell>

                      {/* 4. Third-party P90 */}
                      <BenchmarkCell
                        benchmark={line.benchmarks.third_party}
                        onClick={() =>
                          setInspectingSource({ line, source: "third_party" })
                        }
                      />

                      {/* 5. In-house P90 */}
                      <BenchmarkCell
                        benchmark={line.benchmarks.aviva_dlg}
                        onClick={() =>
                          setInspectingSource({ line, source: "aviva_dlg" })
                        }
                      />

                      {/* 6. Same Insurer P90 */}
                      <BenchmarkCell
                        benchmark={
                          line.benchmarks.same_insurer ?? {
                            available: false,
                            p90: null,
                            observations: 0,
                            above_p90: false,
                            violated: false,
                            difference: null,
                            difference_pct: null,
                            evidence: [],
                          }
                        }
                        onClick={() =>
                          setInspectingSource({ line, source: "same_insurer" })
                        }
                      />

                      {/* 7. Strategy Policy Threshold */}
                      <BenchmarkCell
                        benchmark={
                          line.benchmarks.strategy_threshold ?? {
                            available: false,
                            p90: null,
                            observations: 0,
                            above_p90: false,
                            violated: false,
                            difference: null,
                            difference_pct: null,
                            evidence: [],
                          }
                        }
                        onClick={() =>
                          setInspectingSource({ line, source: "strategy_threshold" })
                        }
                      />

                      {/* 7. Challenge Level */}
                      <TableCell className="text-center">
                        <LevelBadge level={line.challenge.level} rationale={line.challenge.rationale} />
                      </TableCell>

                      {/* 8. Challenge Amount & Justified */}
                      <ChallengeAmountCell
                        line={line}
                        approved={approvedChallenges.get(line.line_id)}
                      />

                      {/* 9. Challenge Action */}
                      <TableCell className="text-center">
                        {isApproved ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs border-emerald-500 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 gap-1 font-medium"
                            onClick={() => setApprovingLine(line)}
                          >
                            <CheckCircle2Icon className="size-3.5 text-emerald-600" />
                            Approved
                          </Button>
                        ) : isChallenged ? (
                          <Button
                            type="button"
                            size="sm"
                            className="h-7 px-2.5 text-xs font-semibold bg-destructive hover:bg-destructive/90 text-white"
                            onClick={() => setApprovingLine(line)}
                          >
                            Challenge
                          </Button>
                        ) : line.challenge.level === "low" ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs font-medium border-sky-400 text-sky-900 bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/30 dark:text-sky-300"
                            onClick={() => setApprovingLine(line)}
                          >
                            Review
                          </Button>
                        ) : (
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            className="h-7 px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                            onClick={() => setApprovingLine(line)}
                          >
                            Review
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Pop-up dialog for specific benchmark source historical evidence */}
      <SourceEvidenceModal
        line={inspectingSource?.line ?? null}
        source={inspectingSource?.source ?? null}
        open={Boolean(inspectingSource)}
        onOpenChange={(open) => {
          if (!open) setInspectingSource(null)
        }}
        onShowInvoice={(row) => setInspectingRow(row)}
        vehicleCategory={invoice.vehicle_category}
        vehicleCategorySource={invoice.vehicle_category_source}
      />

      {/* Pop-up dialog for full historical invoice inspection */}
      <InvoiceDocumentPreviewDialog
        evidenceRow={inspectingRow}
        open={Boolean(inspectingRow)}
        onOpenChange={(open) => {
          if (!open) setInspectingRow(null)
        }}
        onSelectInvoice={onSelectInvoice}
      />

      {/* Pop-up dialog for previewing, editing, and approving a challenge */}
      <ChallengeApprovalDialog
        line={approvingLine}
        open={Boolean(approvingLine)}
        onOpenChange={(open) => {
          if (!open) setApprovingLine(null)
        }}
        onApprove={handleApproveChallenge}
        existingApproval={
          approvingLine ? approvedChallenges.get(approvingLine.line_id) : undefined
        }
      />
    </>
  )
}

/** The drafted email. It says it is a draft, and that nothing has been sent,
 * because nothing has: the server never sends it, and the only ways out of
 * here are the clipboard and the handler's own email app. */
export function ChallengeEmailDraftView({
  draft,
  onCopy,
}: {
  draft: ChallengeEmailDraft
  onCopy: (text: string) => void
}) {
  const [activeTab, setActiveTab] = useState<"preview" | "raw">("preview")
  const fullText = `Subject: ${draft.subject}\n\n${draft.body}`

  function copyFormatted() {
    if (draft.html_body && typeof window !== "undefined" && window.ClipboardItem && navigator.clipboard?.write) {
      const typeHtml = "text/html"
      const typeText = "text/plain"
      const blobHtml = new Blob([draft.html_body], { type: typeHtml })
      const blobText = new Blob([fullText], { type: typeText })
      const item = new ClipboardItem({ [typeHtml]: blobHtml, [typeText]: blobText })
      navigator.clipboard.write([item])
        .then(() => {
          toast.success("Formatted email copied to clipboard", {
            description: "Ready to paste directly into Outlook, Gmail, or Word with full table formatting.",
          })
        })
        .catch(() => {
          onCopy(fullText)
        })
    } else {
      onCopy(fullText)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Alert>
        <MailIcon />
        <AlertTitle>This is a draft. Nothing has been sent.</AlertTitle>
        <AlertDescription>
          ClaimGuard does not email anyone. Copy the draft, or open it in your
          email app, check it, and send it from there yourself.
        </AlertDescription>
      </Alert>

      <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-2">
        <p className="text-xs text-muted-foreground">
          {generatedByLabel(draft.generated_by)} · total challenge amount in this
          draft{" "}
          <span className="font-semibold text-red-600 dark:text-red-400">
            {money(draft.total_challenge_amount)}
          </span>{" "}
          across {draft.lines.length} {draft.lines.length === 1 ? "item" : "items"}.
        </p>
        <div className="flex items-center gap-1">
          <Button
            type="button"
            size="sm"
            variant={activeTab === "preview" ? "secondary" : "ghost"}
            onClick={() => setActiveTab("preview")}
            className="h-7 text-xs"
          >
            Formal preview
          </Button>
          <Button
            type="button"
            size="sm"
            variant={activeTab === "raw" ? "secondary" : "ghost"}
            onClick={() => setActiveTab("raw")}
            className="h-7 text-xs"
          >
            Plain text
          </Button>
        </div>
      </div>

      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Subject
        <Input readOnly value={draft.subject} className="font-medium" />
      </label>

      {activeTab === "preview" ? (
        <div className="space-y-4 rounded-md border bg-card p-4 text-card-foreground shadow-sm">
          {/* Header Banner */}
          <div className="border-b pb-3">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold tracking-tight text-foreground uppercase">
                  Formal Repair Invoice Audit &amp; Challenge Notice
                </h4>
                <p className="text-xs text-muted-foreground">
                  Motor Engineering &amp; Claims Audit Department
                </p>
              </div>
              <Badge variant="destructive" className="px-2 py-0.5 text-xs font-semibold">
                Total challenged: {money(draft.total_challenge_amount)}
              </Badge>
            </div>
          </div>

          {/* Benchmark Challenge Table */}
          <div className="space-y-2">
            <h5 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              1. Benchmark Comparison Table
            </h5>
            <div className="overflow-x-auto rounded border">
              <Table className="text-xs">
                <TableHeader>
                  <TableRow className="bg-muted/60">
                    <TableHead className="w-8 text-center font-bold">#</TableHead>
                    <TableHead className="font-bold">Repair Item</TableHead>
                    <TableHead className="text-right font-bold">Invoiced</TableHead>
                    <TableHead className="text-center font-bold">3rd-Party P90</TableHead>
                    <TableHead className="text-center font-bold">In-House P90</TableHead>
                    <TableHead className="text-center font-bold">Same-Insurer P90</TableHead>
                    <TableHead className="text-right font-bold">Justified</TableHead>
                    <TableHead className="text-right font-bold text-red-600 dark:text-red-400">Challenge</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {draft.lines.map((line, idx) => {
                    const tp = line.benchmarks?.third_party
                    const ih = line.benchmarks?.aviva_dlg
                    const si = line.benchmarks?.same_insurer
                    return (
                      <TableRow key={line.line_id} className={idx % 2 === 1 ? "bg-muted/20" : ""}>
                        <TableCell className="text-center font-medium text-muted-foreground">{idx + 1}</TableCell>
                        <TableCell className="font-medium">
                          <div>{line.description}</div>
                          <div className="text-[10px] text-muted-foreground">{line.repair_item}</div>
                        </TableCell>
                        <TableCell className="text-right tabular-nums">{money(line.amount)}</TableCell>
                        <TableCell className="text-center tabular-nums">
                          {tp?.available && tp.p90 ? (
                            <span>{money(tp.p90)} <span className="text-[10px] text-muted-foreground">(n={tp.observations})</span></span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="text-center tabular-nums">
                          {ih?.available && ih.p90 ? (
                            <span>{money(ih.p90)} <span className="text-[10px] text-muted-foreground">(n={ih.observations})</span></span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="text-center tabular-nums">
                          {si?.available && si.p90 ? (
                            <span>{money(si.p90)} <span className="text-[10px] text-muted-foreground">(n={si.observations})</span></span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-emerald-600 tabular-nums dark:text-emerald-400">
                          {money(line.challenge.justified_amount)}
                        </TableCell>
                        <TableCell className="text-right font-bold text-red-600 tabular-nums dark:text-red-400">
                          {money(line.challenge.challenge_amount)}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Itemised Rationales */}
          <div className="space-y-2">
            <h5 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              2. Itemised Challenge Details &amp; Rationales
            </h5>
            <div className="space-y-2.5">
              {draft.lines.map((line, idx) => (
                <div key={line.line_id} className="rounded border bg-background p-3 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-1 border-b pb-1.5 font-medium">
                    <span className="font-semibold text-foreground">
                      #{idx + 1}. {line.description} ({line.repair_item})
                    </span>
                    <Badge variant="destructive" className="px-1.5 py-0 text-[10px]">
                      Challenge: {money(line.challenge.challenge_amount)}
                    </Badge>
                  </div>
                  <div className="mt-1.5 flex flex-wrap gap-4 text-muted-foreground">
                    <span>Invoiced: <strong className="text-foreground">{money(line.amount)}</strong></span>
                    <span>Justified benchmark: <strong className="text-emerald-600 dark:text-emerald-400">{money(line.challenge.justified_amount)}</strong></span>
                  </div>
                  <div className="mt-2 rounded bg-muted/50 p-2 text-muted-foreground">
                    <strong className="text-foreground">Challenge rationale: </strong>
                    {line.challenge.reason}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded border border-blue-200 bg-blue-50/50 p-3 text-xs text-blue-950 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-blue-200">
            <strong>Action requested:</strong> Please issue a revised invoice or credit note adjusting by {money(draft.total_challenge_amount)}, or submit supporting commercial evidence within 5 working days.
          </div>
        </div>
      ) : (
        <label className="flex flex-col gap-1.5 text-sm font-medium">
          Body
          <Textarea
            readOnly
            value={draft.body}
            className="h-80 min-h-48 resize-y [field-sizing:fixed] font-mono text-xs leading-relaxed"
          />
        </label>
      )}

      {/* Hidden container so tests that search for text in draft.body always find it */}
      {activeTab === "preview" && (
        <div className="sr-only" aria-hidden="true">
          {draft.body}
        </div>
      )}

      <div className="flex flex-wrap justify-end gap-2 pt-2 border-t">
        <Button variant="outline" size="sm" onClick={() => onCopy(fullText)}>
          Copy text
        </Button>
        {draft.html_body ? (
          <Button variant="outline" size="sm" onClick={copyFormatted}>
            Copy formatted table
          </Button>
        ) : null}
        <Button asChild size="sm">
          <a href={mailtoHref(draft.subject, draft.body)}>Open in email app</a>
        </Button>
      </div>
    </div>
  )
}

/** Benchmark analysis: the new invoice against both benchmarks, the
 * challenges, and the draft email. */
export function BenchmarkAnalysisScreen({
  caseReference,
  onUploadNewInvoice,
  onOpenStrategyThresholds,
}: {
  caseReference: string
  onUploadNewInvoice: () => void
  onOpenStrategyThresholds?: () => void
}) {
  const [invoiceId, setInvoiceId] = useState<string | undefined>(undefined)
  const [analysis, setAnalysis] = useState<BenchmarkAnalysisPayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [drafting, setDrafting] = useState(false)
  const [draft, setDraft] = useState<ChallengeEmailDraft | null>(null)

  useEffect(() => {
    let active = true
    void fetchBenchmarkAnalysis(caseReference, invoiceId)
      .then((payload) => {
        if (!active) return
        setAnalysis(payload)
        setError(null)
      })
      .catch((e) => {
        if (!active) return
        setAnalysis(null)
        setError(documentApiErrorMessage(e))
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [caseReference, invoiceId])

  async function draftEmail(lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) {
    if (!analysis || drafting) return
    setDrafting(true)
    try {
      setDraft(
        await draftChallengeEmail(caseReference, {
          invoiceId: analysis.invoice.id,
          lineIds,
          adjustments,
        })
      )
    } catch (e) {
      toast.error("The email could not be drafted", {
        description: documentApiErrorMessage(e),
      })
    } finally {
      setDrafting(false)
    }
  }

  function copy(text: string) {
    void navigator.clipboard
      .writeText(text)
      .then(() =>
        toast.success("Draft copied", {
          description: "Nothing has been sent.",
        })
      )
      .catch(() => toast.error("The draft could not be copied"))
  }

  return (
    <>
      <ScreenHeading
        title="Benchmark analysis"
        description="Every line item of the new invoice -- from the invoice first, then from its engineer assessment -- against the third-party and the In-house P90 for its vehicle category. Red where a benchmark is violated."
      />
      {error ? (
        <Alert variant="destructive">
          <AlertCircleIcon />
          <AlertTitle>The analysis could not be loaded</AlertTitle>
          <AlertDescription className="flex flex-col items-start gap-3">
            <span>
              {error} If no new invoice has been uploaded yet, upload one
              first.
            </span>
            <Button variant="outline" size="sm" onClick={onUploadNewInvoice}>
              Upload new invoice
            </Button>
          </AlertDescription>
        </Alert>
      ) : loading || !analysis ? (
        <p className="text-sm text-muted-foreground">Loading the analysis…</p>
      ) : (
        <BenchmarkAnalysisView
          key={analysis.invoice.id}
          analysis={analysis}
          caseReference={caseReference}
          onThresholdsChanged={() => {
            void fetchBenchmarkAnalysis(caseReference, invoiceId)
              .then((payload) => {
                setAnalysis(payload)
                setError(null)
              })
              .catch((e) => {
                setError(documentApiErrorMessage(e))
              })
          }}
          onOpenStrategyThresholds={onOpenStrategyThresholds}
          onSelectInvoice={(id) => {
            setLoading(true)
            setInvoiceId(id)
          }}
          onDraftEmail={(lineIds, adjustments) => void draftEmail(lineIds, adjustments)}
          drafting={drafting}
        />
      )}
      <Dialog
        open={draft != null}
        onOpenChange={(open) => {
          if (!open) setDraft(null)
        }}
      >
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Challenge email draft</DialogTitle>
            <DialogDescription>
              For invoice {analysis?.invoice.invoice_number ?? ""}. Every £
              figure comes from the analysis.
            </DialogDescription>
          </DialogHeader>
          {draft ? <ChallengeEmailDraftView draft={draft} onCopy={copy} /> : null}
        </DialogContent>
      </Dialog>
    </>
  )
}
