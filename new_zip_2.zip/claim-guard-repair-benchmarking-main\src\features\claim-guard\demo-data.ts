export { screenTitles, screenStage, strategyThreshold, strategyThresholds } from "./navigation"

export const DEMO_CASE_REFERENCE = "CG-2026-0048"
