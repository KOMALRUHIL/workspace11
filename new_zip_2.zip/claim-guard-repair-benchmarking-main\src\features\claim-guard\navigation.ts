import {
  BarChart3Icon,
  ClipboardCheckIcon,
  FileClockIcon,
  FileTextIcon,
  FolderSearch2Icon,
  GaugeIcon,
  LayoutDashboardIcon,
  LibraryBigIcon,
  LinkIcon,
  ScaleIcon,
  SearchCheckIcon,
  Share2Icon,
  SlidersHorizontalIcon,
  UploadIcon,
} from "lucide-react"

import type { ScreenId } from "./types"

/** The sidebar's information architecture, kept out of `app-shell.tsx` so
 * the fast-refresh lint rule keeps that file to components, and so it can be
 * asserted on its own. Locked by `app-shell.test.ts`. */

export interface NavigationItem {
  id: ScreenId
  label: string
  icon: typeof LayoutDashboardIcon
}

/** The left navigation Neha dictated on the 17 Sep walkthrough: "two major
 * headings. Insurer Third Party invoices and EXL/ In house Benchmark invoices. Under every
 * heading … upload documents … document intelligence … benchmark
 * computation", then a third heading, "upload new invoice", whose last step
 * is benchmark analysis. */
export const navigationSections: Array<{
  id: string
  label: string
  items: NavigationItem[]
}> = [
  {
    id: "new-invoice",
    label: "Audit new invoice",
    items: [
      { id: "new-invoice-upload", label: "Upload", icon: UploadIcon },
      {
        id: "new-invoice-intelligence",
        label: "Document intelligence",
        icon: FileTextIcon,
      },
      { id: "benchmark-analysis", label: "Benchmark analysis", icon: ScaleIcon },
    ],
  },
  {
    id: "third-party",
    label: "Third party insurer invoice",
    items: [
      { id: "tp-upload", label: "Upload documents", icon: UploadIcon },
      { id: "tp-intelligence", label: "Document intelligence", icon: FileTextIcon },
      { id: "tp-benchmarks", label: "Benchmark computation", icon: BarChart3Icon },
    ],
  },
  {
    id: "aviva-dlg",
    label: "In-house invoices",
    items: [
      { id: "dlg-upload", label: "Upload documents", icon: UploadIcon },
      { id: "dlg-intelligence", label: "Document intelligence", icon: FileTextIcon },
      { id: "dlg-benchmarks", label: "Benchmark computation", icon: BarChart3Icon },
    ],
  },
  {
    id: "strategy-thresholds",
    label: "Insurer Strategy Thresholds",
    items: [
      {
        id: "insurer-statutory-thresholds",
        label: "Strategy thresholds",
        icon: SlidersHorizontalIcon,
      },
    ],
  },
]

/** Every screen that predates her structure. Moved here on 18 Sep rather
 * than deleted: they still work, and some (the audit trail, the external
 * price library) are the only way to reach what they show. */
export const advancedTools: NavigationItem[] = [
  { id: "benchmark-setup", label: "Benchmark data setup", icon: LibraryBigIcon },
  {
    id: "upload-processing",
    label: "Document Intelligence (whole claim)",
    icon: FileTextIcon,
  },
  { id: "document-mapping", label: "Mapping review", icon: LinkIcon },
  {
    id: "benchmark-dashboard",
    label: "Repair Price Benchmarking",
    icon: BarChart3Icon,
  },
  { id: "in-house-benchmarks", label: "In-house Benchmark", icon: BarChart3Icon },
  { id: "price-comparison", label: "Challenged invoices", icon: SearchCheckIcon },
  { id: "challenge-review", label: "Challenge decision", icon: ClipboardCheckIcon },
  { id: "knowledge-graph", label: "Knowledge graph", icon: Share2Icon },
  { id: "claim-liability", label: "Claim & liability", icon: ClipboardCheckIcon },
  { id: "review-findings-all", label: "Review findings", icon: SearchCheckIcon },
  {
    id: "ontology-mapping",
    label: "Repair item matching",
    icon: FolderSearch2Icon,
  },
  { id: "missing-items", label: "Manual review", icon: GaugeIcon },
  { id: "ontology-bank", label: "External price library", icon: LibraryBigIcon },
  { id: "audit-reports", label: "Audit trail", icon: FileClockIcon },
]

/** Sub-views that have no entry of their own highlight the entry they are
 * reached from. */
const SUB_VIEW_PARENTS: Partial<Record<ScreenId, ScreenId>> = {
  "document-pages": "upload-processing",
  "extracted-invoice": "upload-processing",
  "calculation-checks": "upload-processing",
}

export function activeEntryId(activeScreen: ScreenId): ScreenId {
  return SUB_VIEW_PARENTS[activeScreen] ?? activeScreen
}

export const screenTitles: Record<ScreenId, string> = {
  "tp-upload": "Insurer Third Party – Upload Documents",
  "tp-intelligence": "Insurer Third Party – Document Intelligence",
  "tp-benchmarks": "Insurer Third Party – Benchmark Computation",
  "dlg-upload": "In-house Benchmark – Upload Documents",
  "dlg-intelligence": "In-house Benchmark – Document Intelligence",
  "dlg-benchmarks": "In-house Benchmark – Benchmark Computation",
  "insurer-statutory-thresholds": "Insurer Strategy Thresholds",
  "new-invoice-upload": "Upload New Invoice",
  "new-invoice-intelligence": "New Invoice – Document Intelligence",
  "benchmark-analysis": "Benchmark Analysis",
  "benchmark-setup": "Benchmark Data Setup",
  "claim-liability": "Claim & Liability Decision",
  "upload-processing": "Document Intelligence",
  "document-mapping": "Mapping Review",
  "document-pages": "Source Documents",
  "extracted-invoice": "Review Extraction",
  "calculation-checks": "Calculation Checks",
  "ontology-mapping": "Repair Item Matching",
  "price-comparison": "Challenged Invoices",
  "review-findings-all": "Review Findings",
  "missing-items": "Manual Review & Evidence",
  "challenge-review": "Challenge Decision",
  "ontology-bank": "External Price Library",
  "benchmark-dashboard": "Repair Price Benchmarking",
  "in-house-benchmarks": "In-house Benchmark",
  "knowledge-graph": "Knowledge Graph",
  "audit-reports": "Audit Trail & Verification",
}

export const screenStage: Record<ScreenId, string> = {
  "tp-upload": "documents",
  "tp-intelligence": "documents",
  "tp-benchmarks": "validation",
  "dlg-upload": "documents",
  "dlg-intelligence": "documents",
  "dlg-benchmarks": "validation",
  "insurer-statutory-thresholds": "validation",
  "new-invoice-upload": "documents",
  "new-invoice-intelligence": "documents",
  "benchmark-analysis": "challenge",
  "benchmark-setup": "validation",
  "claim-liability": "liability",
  "upload-processing": "documents",
  "document-mapping": "documents",
  "document-pages": "documents",
  "extracted-invoice": "documents",
  "calculation-checks": "documents",
  "ontology-mapping": "validation",
  "price-comparison": "challenge",
  "review-findings-all": "validation",
  "missing-items": "validation",
  "challenge-review": "challenge",
  "ontology-bank": "validation",
  "benchmark-dashboard": "validation",
  "in-house-benchmarks": "validation",
  "knowledge-graph": "validation",
  "audit-reports": "challenge",
}

export const strategyThreshold = {
  envCharge: 20.0,
  labourRate: 70.0,
  preCleanPostClean: 50.0,
  engineerFee: 0.0,
  preRepairClean: 10.0,
}

export const strategyThresholds = strategyThreshold

