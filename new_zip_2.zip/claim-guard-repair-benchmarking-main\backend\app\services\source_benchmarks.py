"""Two benchmark sources, vehicle category, benchmark analysis and challenges.

Implements ``BUILD_SPEC_2026-09-18_benchmarks-and-challenges.md``.

**Population of a source** (``third_party`` = ``historical_claim`` uploads,
``aviva_dlg`` = ``in_house`` uploads).  Only that source's uploaded invoices:
each invoice's own priced lines -- never a rolled-up section total -- plus the
paired engineer assessment's rows behind a rolled-up total, and only when that
section total agrees with the assessment's (the 15 Sep rule, read off
``section_breakdown_for_invoice``'s ``matches``).  No synthetic rows, no seed
workbook rows: nothing here reads ``historical_observations``.

**Repair item identity.**  An invoice line takes the identity
``case_result._uploaded_line_identity`` already gives it everywhere uploaded
lines are benchmarked: the approved ontology item's canonical name when the
line is mapped, otherwise its normalised description
(``canonical_benchmark_category``).  An assessment row carries no ontology
mapping, so it is always the normalised description -- the same space, so a
"L/R DOOR" printed on an invoice and on an assessment meet.  The key is that
name slugged; rows are grouped by (vehicle category, repair item key, price
kind), where price kind keeps a part's price apart from the labour to fit it
(parts / labour incl. paintwork / paint materials / extras and charges).

**Vehicle category** comes from ``app.services.vehicle_category`` (lookup ->
AI, cached -> Unknown).  Only invoices in a category feed that category's P90;
one observation is a valid P90 and ``n`` is always shown beside it.

**Challenge rule** uses the 50/50 average of both source P90s. Both sources
are required. The percentage and minimum thresholds are read from the
frozen ``price_decision.DEFAULT_POLICY``: a benchmark is violated when the
line exceeds the combined price by more than the threshold *and* by at least the minimum
challenge amount.  High = both source P90s violated, Medium = one, provided the blended rule
also qualifies; Low = above a source P90 without an actionable blended challenge.  ``price_decision.py`` itself is not used or changed: this is
a separate analysis, and the 50/30/20 blend is not involved.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.config import get_settings
from app.domain.normalisation import normalise_description, strip_part_codes
from app.domain.price_decision import DEFAULT_POLICY
from app.enums import AuditActorType, DocumentKind, InvoiceDocumentRole, LineItemKind, ReviewStatus
from app.llm import benchmark_writing
from app.models import (
    AssessmentOperation,
    AuditEvent,
    Case,
    EngineerAssessment,
    Invoice,
    OntologyItem,
    OntologyMapping,
)
from app.services.benchmarking import calculate_benchmark_statistics, canonical_benchmark_category
from app.services.case_result import (
    _assessment_section_verdicts,
    _is_assessment_total_lookalike,
    _latest_by,
    _uploaded_line_identity,
)
from app.services.engineer_assessment import section_breakdown_for_invoice
from app.services.strategy_thresholds import match_strategy_threshold
from app.services.vehicle_category import VehicleCategory, VehicleCategoryResolver

CENT = Decimal("0.01")
HUNDRED = Decimal("100")


@dataclass(frozen=True, slots=True)
class BenchmarkSource:
    key: str
    intake_group: str
    label: str
    #: How the source is named inside a sentence.
    phrase: str


SOURCES: dict[str, BenchmarkSource] = {
    "third_party": BenchmarkSource(
        "third_party", "historical_claim", "Insurer Third Party invoices", "third-party"
    ),
    "aviva_dlg": BenchmarkSource("aviva_dlg", "in_house", "In-house Benchmark invoices", "In-house"),
    "same_insurer": BenchmarkSource(
        "same_insurer", "historical_claim", "Same Insurer invoices", "same insurer"
    ),
}
LIVE_GROUP = "live"
ORIGIN_INVOICE = "invoice"
ORIGIN_ASSESSMENT = "engineer_assessment"

#: The price kind a section code belongs to; anything else is an extra/charge.
_PRICE_KIND = {
    "parts": "parts",
    "labour": "labour",
    "paint": "labour",
    "paint_materials": "paint_materials",
}
_KIND_BY_ITEM_KIND = {
    LineItemKind.PART.value: "parts",
    LineItemKind.LABOUR.value: "labour",
    LineItemKind.PAINT.value: "labour",
}


class BenchmarkAnalysisError(ValueError):
    def __init__(self, code: str, message: str, status_code: int = 422) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code


# ---------------------------------------------------------------------------
# Money helpers
# ---------------------------------------------------------------------------


def _money(value: Decimal) -> Decimal:
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def _text(value: Decimal | None) -> str | None:
    return None if value is None else f"{_money(value):.2f}"


def _gbp(value: Decimal | str) -> str:
    return f"£{_money(Decimal(str(value))):,.2f}"


def _amount(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    return Decimal(str(value))


def _enum_value(value: Any) -> Any:
    return getattr(value, "value", value)


# ---------------------------------------------------------------------------
# D3: one line against one benchmark, then against all available
# ---------------------------------------------------------------------------


def compare_to_benchmark(
    amount: Decimal | None,
    p90: Decimal | None,
    observations: int,
    *,
    threshold_pct: Decimal,
    minimum: Decimal = DEFAULT_POLICY.minimum_challenge_amount,
) -> dict[str, Any]:
    """One line against one source's P90 for its category and repair item.

    A repair item with no observations in the source is *unavailable*: not a
    zero P90, and never violated.  Comparisons use exact values; only the
    displayed figures are rounded.
    """

    if observations <= 0 or p90 is None:
        return {
            "available": False,
            "p90": None,
            "observations": 0,
            "above_p90": False,
            "violated": False,
            "difference": None,
            "difference_pct": None,
        }
    if amount is None:
        return {
            "available": True,
            "p90": _text(p90),
            "observations": observations,
            "above_p90": False,
            "violated": False,
            "difference": None,
            "difference_pct": None,
        }
    difference = amount - p90
    percentage = (difference / p90 * HUNDRED) if p90 > 0 else None
    above = difference > 0
    violated = (
        above
        and percentage is not None
        and percentage > threshold_pct
        and difference >= minimum
    )
    return {
        "available": True,
        "p90": _text(p90),
        "observations": observations,
        "above_p90": above,
        "violated": bool(violated),
        "difference": _text(difference),
        "difference_pct": _text(percentage),
    }


def _source_phrase(key: str) -> str:
    source = SOURCES.get(key)
    return source.phrase if source else key


def _cited(key: str, comparison: dict[str, Any]) -> str:
    return (
        f"the {_source_phrase(key)} P90 ({_gbp(comparison['p90'])}, "
        f"n={comparison['observations']})"
    )


def normalize_semantic_description(desc: str | None) -> str:
    """Normalize descriptions to detect semantic duplicates (e.g. pre repair clean vs pre repair cleaning charge)."""
    if not desc:
        return ""
    text = desc.lower().strip()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    # Normalize common OCR typos and word variants
    text = re.sub(r"\b(clinic|clenic)\b", "clean", text)
    text = re.sub(r"\b(cleaning|cleaned)\b", "clean", text)
    text = re.sub(r"\b(valeting|valeted)\b", "valet", text)
    text = re.sub(r"\b(washing|washed)\b", "wash", text)
    text = re.sub(r"\b(painting|painted)\b", "paint", text)
    text = re.sub(r"\b(materials)\b", "material", text)
    text = re.sub(r"\b(sustainability)\b", "sustainable", text)
    # Remove generic fee/charge filler words
    text = re.sub(
        r"\b(charge|charges|fee|fees|cost|costs|amount|investment|the|a|an|and)\b",
        " ",
        text,
    )
    tokens = sorted(w for w in text.split() if w)
    return " ".join(tokens)


def challenge_for_line(
    amount: Decimal | None,
    comparisons: dict[str, dict[str, Any]],
    *,
    threshold_pct: Decimal,
    minimum: Decimal = DEFAULT_POLICY.minimum_challenge_amount,
) -> dict[str, Any]:
    """Challenge against the available independent source P90s.

    When 3 sources are available: equal 33.33% (1/3) blend each.
    When 2 sources are available: 50% / 50% blend each.
    When 1 source is available: 100% of that benchmark.
    When 0 sources are available: waiting for observations.
    """
    result = {
        "is_challenge": False,
        "level": None,
        "justified_amount": None,
        "challenge_amount": "0.00",
        "reason": "",
    }
    if amount is None:
        result["reason"] = "The line carries no amount to compare."
        return result

    # When an insurer policy strategy threshold is defined for this line, it takes
    # precedence over standard benchmark averages and enforces the maximum policy cap directly.
    strat_comp = comparisons.get("strategy_threshold")
    if strat_comp and strat_comp.get("available") and strat_comp.get("p90") is not None:
        strat_cap = Decimal(strat_comp["p90"])
        item_name = strat_comp.get("item_name") or "Policy Strategy Threshold"
        justified = _money(strat_cap)
        if amount > strat_cap:
            diff = _money(amount - strat_cap)
            return {
                "is_challenge": True,
                "level": "high",
                "justified_amount": _text(justified),
                "challenge_amount": _text(diff),
                "reason": (
                    f"Insurer policy strategy threshold cap of {_gbp(strat_cap)} for {item_name} "
                    f"takes precedence over standard benchmarks. The invoiced {_gbp(amount)} exceeds "
                    f"this policy threshold cap by {_gbp(diff)}. Challenge {_gbp(diff)}."
                ),
            }
        else:
            return {
                "is_challenge": False,
                "level": None,
                "justified_amount": _text(justified),
                "challenge_amount": "0.00",
                "reason": (
                    f"Insurer policy strategy threshold cap of {_gbp(strat_cap)} for {item_name} "
                    f"takes precedence over standard benchmarks. The invoiced {_gbp(amount)} is "
                    f"within the policy threshold cap; not challenged."
                ),
            }

    available_keys = [
        key
        for key in ("third_party", "aviva_dlg", "same_insurer")
        if comparisons.get(key, {}).get("available") and comparisons[key].get("p90") is not None
    ]
    if not available_keys:
        result["reason"] = "No observations available for this repair item."
        return result

    count = len(available_keys)
    sum_p90 = sum((Decimal(comparisons[key]["p90"]) for key in available_keys), Decimal("0"))
    justified = _money(sum_p90 / Decimal(count))
    combined = compare_to_benchmark(
        amount, justified, 1, threshold_pct=threshold_pct, minimum=minimum
    )
    citation = " and ".join(_cited(key, comparisons[key]) for key in available_keys)
    if count == 3:
        prefix = f"33.3% equal blend of {citation} = {_gbp(justified)}. "
    elif count == 2:
        prefix = f"Combined benchmark average of {citation} = {_gbp(justified)}. "
    else:
        prefix = f"Benchmark of {citation} = {_gbp(justified)}. "
    basis = prefix

    if combined["violated"]:
        violated = [key for key in available_keys if comparisons[key]["violated"]]
        challenge = _money(amount - justified)
        level = "high" if len(violated) == count else "medium"
        return {
            "is_challenge": True,
            "level": level,
            "justified_amount": _text(justified),
            "challenge_amount": _text(challenge),
            "reason": basis + (
                f"The invoiced {_gbp(amount)} exceeds this combined price by "
                f"{combined['difference_pct']}%, beyond the {threshold_pct.normalize():f}% "
                f"threshold and the {_gbp(minimum)} minimum. Challenge {_gbp(challenge)}."
            ),
        }
    above = any(comparisons[key]["above_p90"] for key in available_keys)
    result["level"] = "low" if above else None
    result["justified_amount"] = _text(justified)
    result["reason"] = basis + (
        f"Within the {threshold_pct.normalize():f}% threshold or under the {_gbp(minimum)} "
        "minimum against the combined price; not challenged."
        if amount > justified else "At or below the combined price; not challenged."
    )
    return result


# ---------------------------------------------------------------------------
# Loading and the rows each invoice contributes
# ---------------------------------------------------------------------------


@dataclass
class _CaseData:
    case: Case
    invoices: list[Invoice]
    assessments: list[EngineerAssessment]
    assessment_by_invoice: dict[str, EngineerAssessment]
    latest_mappings: dict[str, OntologyMapping]
    ontology: dict[str, OntologyItem]
    resolver: VehicleCategoryResolver
    breakdowns: dict[str, list[dict[str, Any]]] = field(default_factory=dict)


def _intake_group(invoice: Invoice) -> str | None:
    return ((invoice.document.metadata_json if invoice.document else None) or {}).get(
        "intake_group"
    )


def _assessment_intake_group(assessment: EngineerAssessment) -> str | None:
    return ((assessment.document.metadata_json if assessment.document else None) or {}).get(
        "intake_group"
    )


def _is_uploaded_invoice(invoice: Invoice) -> bool:
    return (
        _enum_value(invoice.document_role) == InvoiceDocumentRole.INVOICE.value
        and invoice.document is not None
        and _enum_value(invoice.document.document_kind) != DocumentKind.ENGINEER_ASSESSMENT.value
    )


def _load(session: Session, case: Case) -> _CaseData:
    invoices = list(
        session.scalars(
            select(Invoice)
            .where(Invoice.case_id == case.id)
            .options(
                selectinload(Invoice.vehicle),
                selectinload(Invoice.document),
                selectinload(Invoice.line_items),
            )
            .order_by(Invoice.created_at, Invoice.id)
        )
        .unique()
        .all()
    )
    assessments = list(
        session.scalars(
            select(EngineerAssessment)
            .where(EngineerAssessment.case_id == case.id)
            .options(
                selectinload(EngineerAssessment.operations),
                selectinload(EngineerAssessment.document),
            )
            .order_by(EngineerAssessment.created_at, EngineerAssessment.id)
        ).all()
    )
    assessment_by_invoice: dict[str, EngineerAssessment] = {}
    for assessment in assessments:
        if assessment.paired_invoice_id:
            # First in load order wins, as in the extracts endpoint.
            assessment_by_invoice.setdefault(assessment.paired_invoice_id, assessment)
    line_ids = [line.id for invoice in invoices for line in invoice.line_items]
    mappings = (
        list(
            session.scalars(
                select(OntologyMapping).where(OntologyMapping.invoice_line_item_id.in_(line_ids))
            ).all()
        )
        if line_ids
        else []
    )
    latest_mappings = _latest_by(mappings, "invoice_line_item_id")
    ontology_ids = {
        mapping.selected_ontology_item_id
        for mapping in latest_mappings.values()
        if mapping.selected_ontology_item_id
    }
    ontology = (
        {
            item.id: item
            for item in session.scalars(
                select(OntologyItem).where(OntologyItem.id.in_(ontology_ids))
            ).all()
        }
        if ontology_ids
        else {}
    )
    return _CaseData(
        case=case,
        invoices=invoices,
        assessments=assessments,
        assessment_by_invoice=assessment_by_invoice,
        latest_mappings=latest_mappings,
        ontology=ontology,
        resolver=VehicleCategoryResolver(session),
    )


def _vehicle_category(data: _CaseData, invoice: Invoice) -> VehicleCategory:
    vehicle = invoice.vehicle
    return data.resolver(
        vehicle.make if vehicle else None,
        vehicle.model if vehicle else None,
    )


def _slug(label: str) -> str:
    cleaned = strip_part_codes(label)
    return re.sub(r"[^a-z0-9]+", "-", cleaned.casefold()).strip("-") or "unlabelled"


def _display(label: str, mapped: bool) -> str:
    return label if mapped else label[:1].upper() + label[1:]


def _price_kind(line_item_type: str | None, item_kind: str | None = None) -> str:
    if line_item_type in _PRICE_KIND:
        return _PRICE_KIND[line_item_type]
    if line_item_type in (None, "", "unknown") and item_kind in _KIND_BY_ITEM_KIND:
        return _KIND_BY_ITEM_KIND[item_kind]
    return "extras"


@dataclass(frozen=True)
class _Row:
    """One priced line an invoice contributes: its own, or its assessment's."""

    origin: str
    line_id: str
    description: str
    line_item_type: str
    kind: str
    amount: Decimal | None
    repair_item: str
    repair_item_key: str
    assessment: EngineerAssessment | None = None


def _breakdowns(session: Session, data: _CaseData, invoice: Invoice) -> list[dict[str, Any]]:
    if invoice.id not in data.breakdowns:
        assessment = data.assessment_by_invoice.get(invoice.id)
        if assessment is None and len(data.assessments) == 1:
            assessment = data.assessments[0]
        data.breakdowns[invoice.id] = section_breakdown_for_invoice(
            session, invoice, assessment
        )
    return data.breakdowns[invoice.id]


def _invoice_rows(session: Session, data: _CaseData, invoice: Invoice) -> list[_Row]:
    """Invoice lines first, then the admitted assessment rows behind totals."""

    rows: list[_Row] = []
    for line in sorted(invoice.line_items, key=lambda item: item.sequence_no):
        if (
            line.is_section_total
            or line.status == ReviewStatus.REJECTED
            or (line.raw_description and line.raw_description.strip().casefold().startswith("total "))
            or (line.raw_description and line.raw_description.strip().casefold().startswith("sub total"))
            or (line.raw_description and line.raw_description.strip().casefold().startswith("subtotal"))
        ):
            # "You cannot compare invoices on totals anywhere."
            continue
        mapping = data.latest_mappings.get(line.id)
        _, label, _ = _uploaded_line_identity(
            line, latest_mappings=data.latest_mappings, ontology=data.ontology
        )
        mapped = bool(mapping and mapping.selected_ontology_item_id in data.ontology)
        line_item_type = line.line_item_type or "unknown"
        rows.append(
            _Row(
                origin=ORIGIN_INVOICE,
                line_id=line.id,
                description=line.raw_description,
                line_item_type=line_item_type,
                kind=_price_kind(line.line_item_type, _enum_value(line.item_kind)),
                amount=_amount(line.line_total_net),
                repair_item=_display(label, mapped),
                repair_item_key=_slug(label),
            )
        )

    assessment = data.assessment_by_invoice.get(invoice.id)
    if assessment is None and len(data.assessments) == 1:
        assessment = data.assessments[0]
    if assessment is None:
        return rows
    operations = {operation.id: operation for operation in assessment.operations}
    # A matched "Total Labour" covers paintwork too, but not when the
    # invoice's own paint & materials total contradicts the assessment's --
    # the same withdrawal the prior-assessment benchmark applies.
    paint_disagrees = (
        _assessment_section_verdicts(invoice, assessment).get("paint_materials") is False
    )
    itemised_kinds = {r.kind for r in rows if r.origin == ORIGIN_INVOICE}
    seen: set[str] = set()
    for breakdown in _breakdowns(session, data, invoice):
        if breakdown["matches"] is not True:
            continue
        breakdown_kind = _price_kind(breakdown.get("line_item_type"))
        if breakdown_kind in itemised_kinds:
            continue
        for row in breakdown["rows"]:
            operation: AssessmentOperation | None = operations.get(row["id"])
            if operation is None or operation.id in seen:
                continue
            if operation.category == "paint" and paint_disagrees:
                continue
            amount = _amount(operation.total_net)
            if amount is None:
                continue
            if _is_assessment_total_lookalike(operation, assessment, amount):
                continue
            seen.add(operation.id)
            label = canonical_benchmark_category(
                operation.raw_description, normalise_description(operation.raw_description)
            )
            rows.append(
                _Row(
                    origin=ORIGIN_ASSESSMENT,
                    line_id=operation.id,
                    description=operation.raw_description,
                    line_item_type=operation.category,
                    kind=_price_kind(operation.category),
                    amount=amount,
                    repair_item=_display(label, False),
                    repair_item_key=_slug(label),
                    assessment=assessment,
                )
            )

    return rows


def _evidence(invoice: Invoice, row: _Row) -> dict[str, Any]:
    vehicle = invoice.vehicle
    document = (
        row.assessment.document
        if row.origin == ORIGIN_ASSESSMENT and row.assessment is not None
        else invoice.document
    )
    return {
        "invoice_id": invoice.id,
        "document_id": document.id if document is not None else None,
        "invoice_number": invoice.invoice_number,
        "document_filename": document.original_filename if document is not None else None,
        "vehicle_make": vehicle.make if vehicle else None,
        "vehicle_model": vehicle.model if vehicle else None,
        "registration": vehicle.registration if vehicle else None,
        "description": row.description,
        "amount": _text(row.amount),
        "origin": row.origin,
        "source_line_id": row.line_id,
        # Additive to the contract: which assessment a row came from.
        "assessment_number": (
            row.assessment.assessment_number
            if row.origin == ORIGIN_ASSESSMENT and row.assessment is not None
            else None
        ),
    }


def _assessment_evidence(assessment: EngineerAssessment, row: _Row) -> dict[str, Any]:
    document = assessment.document
    return {
        "invoice_id": assessment.id,
        "document_id": document.id if document is not None else None,
        "invoice_number": None,
        "document_filename": document.original_filename if document is not None else None,
        "vehicle_make": assessment.vehicle_make,
        "vehicle_model": assessment.vehicle_model,
        "registration": assessment.registration,
        "description": row.description,
        "amount": _text(row.amount),
        "origin": row.origin,
        "source_line_id": row.line_id,
        "assessment_number": assessment.assessment_number,
    }


def _standalone_assessment_rows(assessment: EngineerAssessment) -> list[_Row]:
    rows: list[_Row] = []
    for operation in sorted(assessment.operations, key=lambda item: item.sequence_no):
        amount = _amount(operation.total_net)
        if amount is None or amount <= 0:
            continue
        label = canonical_benchmark_category(
            operation.raw_description, normalise_description(operation.raw_description)
        )
        rows.append(
            _Row(
                origin=ORIGIN_ASSESSMENT,
                line_id=operation.id,
                description=operation.raw_description,
                line_item_type=operation.category,
                kind=_price_kind(operation.category),
                amount=amount,
                repair_item=_display(label, False),
                repair_item_key=_slug(label),
                assessment=assessment,
            )
        )
    return rows


_GroupKey = tuple[str, str, str]


@dataclass
class _Population:
    source: BenchmarkSource
    invoices: list[tuple[Invoice, VehicleCategory]]
    groups: dict[_GroupKey, list[tuple[Decimal, _Row, dict[str, Any]]]]


def _insurer_matches(a: str | None, b: str | None) -> bool:
    if not a or not b:
        return False
    norm_a = re.sub(r"[^a-z0-9]+", " ", a.casefold()).strip()
    norm_b = re.sub(r"[^a-z0-9]+", " ", b.casefold()).strip()
    if not norm_a or not norm_b:
        return False
    return norm_a in norm_b or norm_b in norm_a or norm_a == norm_b


def _population(
    session: Session,
    data: _CaseData,
    source: BenchmarkSource,
    *,
    exclude_invoice_id: str | None = None,
    target_insurer_name: str | None = None,
) -> _Population:
    if source.key == "same_insurer" and not target_insurer_name:
        return _Population(source=source, invoices=[], groups={})

    invoices = [
        invoice
        for invoice in data.invoices
        if _is_uploaded_invoice(invoice)
        and _intake_group(invoice) == source.intake_group
        and invoice.id != exclude_invoice_id
        and (
            source.key != "same_insurer"
            or _insurer_matches(
                invoice.insurer_name
                or (
                    data.assessment_by_invoice[invoice.id].insurer_name
                    if invoice.id in data.assessment_by_invoice
                    else None
                ),
                target_insurer_name,
            )
        )
    ]
    categorised = [(invoice, _vehicle_category(data, invoice)) for invoice in invoices]
    groups: dict[_GroupKey, list[tuple[Decimal, _Row, dict[str, Any]]]] = {}
    for invoice, category in categorised:
        for row in _invoice_rows(session, data, invoice):
            if row.amount is None or row.amount <= 0:
                continue
            key = (category.category, row.repair_item_key, row.kind)
            groups.setdefault(key, []).append((row.amount, row, _evidence(invoice, row)))

    # Include standalone / unpaired assessments in this intake group
    included_invoice_ids = {inv.id for inv in invoices}
    standalone_assessments = [
        assessment
        for assessment in data.assessments
        if _assessment_intake_group(assessment) == source.intake_group
        and (
            assessment.paired_invoice_id is None
            or assessment.paired_invoice_id not in included_invoice_ids
        )
        and assessment.id != exclude_invoice_id
        and (
            source.key != "same_insurer"
            or _insurer_matches(assessment.insurer_name, target_insurer_name)
        )
    ]
    for assessment in standalone_assessments:
        category = data.resolver(assessment.vehicle_make, assessment.vehicle_model)
        for row in _standalone_assessment_rows(assessment):
            if row.amount is None or row.amount <= 0:
                continue
            key = (category.category, row.repair_item_key, row.kind)
            groups.setdefault(key, []).append(
                (row.amount, row, _assessment_evidence(assessment, row))
            )

    for observations in groups.values():
        observations.sort(
            key=lambda item: (
                str(item[2]["invoice_number"] or item[2]["assessment_number"] or ""),
                item[1].origin != ORIGIN_INVOICE,
                item[1].description,
                item[1].line_id,
            )
        )
    return _Population(source=source, invoices=categorised, groups=groups)


def _statistics(observations: list[tuple[Decimal, _Row, dict[str, Any]]]):
    return calculate_benchmark_statistics(amount for amount, _, _ in observations)


# ---------------------------------------------------------------------------
# GET /claims/{ref}/benchmarks?source=
# ---------------------------------------------------------------------------


def _case(session: Session, case_reference: str) -> Case:
    case = session.scalar(select(Case).where(Case.case_reference == case_reference))
    if case is None:
        raise BenchmarkAnalysisError("NOT_FOUND", "Claim not found", 404)
    return case


def _threshold(value: Decimal | None) -> Decimal:
    return Decimal(DEFAULT_POLICY.default_threshold_pct) if value is None else value


def _threshold_text(value: Decimal) -> str:
    return f"{value.normalize():f}"


def build_source_benchmarks(
    session: Session,
    case_reference: str,
    source_key: str,
    *,
    threshold_pct: Decimal | None = None,
) -> dict[str, Any]:
    source = SOURCES.get(source_key)
    if source is None:
        raise BenchmarkAnalysisError(
            "UNKNOWN_SOURCE", f"source must be one of: {', '.join(sorted(SOURCES))}"
        )
    case = _case(session, case_reference)
    data = _load(session, case)
    population = _population(session, data, source)

    rows = []
    for (category, key, kind), observations in population.groups.items():
        statistics = _statistics(observations)
        first_row = observations[0][1]
        rows.append(
            {
                "vehicle_category": category,
                "repair_item": first_row.repair_item,
                "repair_item_key": key,
                "line_item_type": kind,
                "observations": statistics.count,
                "p90": _text(statistics.percentile_90),
                "median": _text(statistics.median),
                "min": _text(statistics.minimum),
                "max": _text(statistics.maximum),
                "evidence": [evidence for _, _, evidence in observations],
            }
        )
    rows.sort(key=lambda row: (row["vehicle_category"], row["line_item_type"], row["repair_item"]))

    by_category: dict[str, list[VehicleCategory]] = {}
    for _, category in population.invoices:
        by_category.setdefault(category.category, []).append(category)
    vehicle_categories = [
        {
            "category": category,
            "invoice_count": len(resolved),
            "source": (
                resolved[0].source
                if len({item.source for item in resolved}) == 1
                else "mixed"
            ),
        }
        for category, resolved in sorted(by_category.items())
    ]
    approval = (case.mapping_group_approvals_json or {}).get(source.intake_group)
    section_breakdowns = []
    for invoice, _ in population.invoices:
        for breakdown in _breakdowns(session, data, invoice):
            section_breakdowns.append(
                {"invoice_id": invoice.id, "invoice_number": invoice.invoice_number, **breakdown}
            )
    return {
        "source": source.key,
        "intake_group": source.intake_group,
        "label": source.label,
        "invoice_count": len(population.invoices),
        "threshold_pct": _threshold_text(_threshold(threshold_pct)),
        "vehicle_categories": vehicle_categories,
        "rows": rows,
        "section_breakdowns": section_breakdowns,
        # Additive to the contract: each vehicle's category and where it came
        # from, and whether this source's mapping has been approved.
        "invoices": [
            {
                "invoice_id": invoice.id,
                "invoice_number": invoice.invoice_number,
                "document_filename": invoice.document.original_filename,
                "vehicle_make": invoice.vehicle.make if invoice.vehicle else None,
                "vehicle_model": invoice.vehicle.model if invoice.vehicle else None,
                "registration": invoice.vehicle.registration if invoice.vehicle else None,
                "vehicle_category": category.category,
                "vehicle_category_source": category.source,
            }
            for invoice, category in population.invoices
        ],
        "mapping_approved": bool(approval),
    }


# ---------------------------------------------------------------------------
# GET /claims/{ref}/benchmark-analysis?invoice_id=
# ---------------------------------------------------------------------------


def _live_invoices(data: _CaseData) -> list[Invoice]:
    return [
        invoice
        for invoice in data.invoices
        if _is_uploaded_invoice(invoice) and _intake_group(invoice) == LIVE_GROUP
    ]


def _analysis_line(
    row: _Row,
    category: VehicleCategory,
    populations: dict[str, _Population],
    threshold_pct: Decimal,
) -> dict[str, Any]:
    comparisons: dict[str, dict[str, Any]] = {}
    for key, population in populations.items():
        observations = population.groups.get(
            (category.category, row.repair_item_key, row.kind), []
        )
        statistics = _statistics(observations)
        compared = compare_to_benchmark(
            row.amount,
            statistics.percentile_90,
            statistics.count,
            threshold_pct=threshold_pct,
        )
        compared["evidence"] = [evidence for _, _, evidence in observations]
        comparisons[key] = compared

    strat = match_strategy_threshold(row.description, row.repair_item)
    if strat:
        strat_diff = (row.amount - strat.max_amount_net) if row.amount is not None else None
        strat_above = strat_diff is not None and strat_diff > 0
        comparisons["strategy_threshold"] = {
            "available": True,
            "p90": _text(strat.max_amount_net),
            "observations": 1,
            "above_p90": strat_above,
            "violated": strat_above,
            "difference": _text(strat_diff),
            "difference_pct": _text(
                (strat_diff / strat.max_amount_net * HUNDRED)
                if strat_diff and strat.max_amount_net > 0
                else None
            ),
            "description": strat.description,
            "item_name": strat.item_name,
            "evidence": [],
        }
    else:
        comparisons["strategy_threshold"] = {
            "available": False,
            "p90": None,
            "observations": 0,
            "above_p90": False,
            "violated": False,
            "difference": None,
            "difference_pct": None,
            "evidence": [],
        }

    return {
        "line_id": row.line_id,
        "origin": row.origin,
        "line_item_type": row.line_item_type,
        "description": row.description,
        "repair_item": row.repair_item,
        "amount": _text(row.amount),
        "benchmarks": comparisons,
        "challenge": challenge_for_line(row.amount, comparisons, threshold_pct=threshold_pct),
    }


def build_benchmark_analysis(
    session: Session,
    case_reference: str,
    *,
    invoice_id: str | None = None,
    threshold_pct: Decimal | None = None,
) -> dict[str, Any]:
    threshold = _threshold(threshold_pct)
    case = _case(session, case_reference)
    data = _load(session, case)
    live = _live_invoices(data)
    live_assessments = [
        a for a in data.assessments if _assessment_intake_group(a) == LIVE_GROUP
    ]
    if invoice_id:
        invoice = next(
            (row for row in data.invoices if row.id == invoice_id and _is_uploaded_invoice(row)),
            None,
        )
        if invoice is None:
            live_assessment = next(
                (row for row in data.assessments if row.id == invoice_id),
                None,
            )
            if live_assessment is None:
                raise BenchmarkAnalysisError(
                    "INVOICE_NOT_FOUND", "Invoice not found in this claim.", 404
                )
            category = data.resolver(live_assessment.vehicle_make, live_assessment.vehicle_model)
            target_insurer_name = live_assessment.insurer_name
            populations = {
                key: _population(
                    session,
                    data,
                    source,
                    exclude_invoice_id=live_assessment.id,
                    target_insurer_name=target_insurer_name,
                )
                for key, source in SOURCES.items()
            }
            lines = [
                _analysis_line(row, category, populations, threshold)
                for row in _standalone_assessment_rows(live_assessment)
            ]
            challenges = [line for line in lines if line["challenge"]["is_challenge"]]
            total = sum(
                (Decimal(line["challenge"]["challenge_amount"]) for line in challenges), Decimal("0")
            )
            return {
                "invoice": {
                    "id": live_assessment.id,
                    "invoice_number": None,
                    "vehicle_make": live_assessment.vehicle_make,
                    "vehicle_model": live_assessment.vehicle_model,
                    "vehicle_category": category.category,
                    "vehicle_category_source": category.source,
                    "registration": live_assessment.registration,
                    "paired_assessment_number": live_assessment.assessment_number,
                    "intake_group": LIVE_GROUP,
                },
                "live_invoices": [
                    {
                        "id": row.id,
                        "invoice_number": row.invoice_number,
                        "registration": row.vehicle.registration if row.vehicle else None,
                    }
                    for row in live
                ] or [
                    {
                        "id": row.id,
                        "invoice_number": row.assessment_number,
                        "registration": row.registration,
                    }
                    for row in live_assessments
                ],
                "threshold_pct": _threshold_text(threshold),
                "minimum_challenge_amount": _text(DEFAULT_POLICY.minimum_challenge_amount),
                "lines": lines,
                "section_breakdowns": [],
                "totals": {
                    "line_count": len(lines),
                    "challenge_count": len(challenges),
                    "by_level": {
                        level: sum(1 for line in lines if line["challenge"]["level"] == level)
                        for level in ("high", "medium", "low")
                    },
                    "total_challenge_amount": _text(total),
                },
            }
    else:
        if not live and live_assessments:
            live_assessment = live_assessments[-1]
            category = data.resolver(live_assessment.vehicle_make, live_assessment.vehicle_model)
            target_insurer_name = live_assessment.insurer_name
            populations = {
                key: _population(
                    session,
                    data,
                    source,
                    exclude_invoice_id=live_assessment.id,
                    target_insurer_name=target_insurer_name,
                )
                for key, source in SOURCES.items()
            }
            lines = [
                _analysis_line(row, category, populations, threshold)
                for row in _standalone_assessment_rows(live_assessment)
            ]
            challenges = [line for line in lines if line["challenge"]["is_challenge"]]
            total = sum(
                (Decimal(line["challenge"]["challenge_amount"]) for line in challenges), Decimal("0")
            )
            return {
                "invoice": {
                    "id": live_assessment.id,
                    "invoice_number": None,
                    "vehicle_make": live_assessment.vehicle_make,
                    "vehicle_model": live_assessment.vehicle_model,
                    "vehicle_category": category.category,
                    "vehicle_category_source": category.source,
                    "registration": live_assessment.registration,
                    "paired_assessment_number": live_assessment.assessment_number,
                    "intake_group": LIVE_GROUP,
                },
                "live_invoices": [
                    {
                        "id": row.id,
                        "invoice_number": row.assessment_number,
                        "registration": row.registration,
                    }
                    for row in live_assessments
                ],
                "threshold_pct": _threshold_text(threshold),
                "minimum_challenge_amount": _text(DEFAULT_POLICY.minimum_challenge_amount),
                "lines": lines,
                "section_breakdowns": [],
                "totals": {
                    "line_count": len(lines),
                    "challenge_count": len(challenges),
                    "by_level": {
                        level: sum(1 for line in lines if line["challenge"]["level"] == level)
                        for level in ("high", "medium", "low")
                    },
                    "total_challenge_amount": _text(total),
                },
            }
        elif not live:
            raise BenchmarkAnalysisError(
                "NO_LIVE_INVOICE", "Upload a new invoice to analyse against the benchmarks.", 404
            )
        invoice = live[-1]

    category = _vehicle_category(data, invoice)
    target_insurer_name = invoice.insurer_name or (
        data.assessment_by_invoice[invoice.id].insurer_name
        if invoice.id in data.assessment_by_invoice
        else (data.assessments[0].insurer_name if len(data.assessments) == 1 else None)
    )
    # The invoice under analysis never helps set its own benchmark.
    populations = {
        key: _population(
            session,
            data,
            source,
            exclude_invoice_id=invoice.id,
            target_insurer_name=target_insurer_name,
        )
        for key, source in SOURCES.items()
    }
    lines = [
        _analysis_line(row, category, populations, threshold)
        for row in _invoice_rows(session, data, invoice)
    ]
    seen_semantic_items: dict[str, int] = {}
    for line in lines:
        if line.get("origin") == ORIGIN_INVOICE:
            desc = line.get("description") or ""
            semantic_key = normalize_semantic_description(desc) or desc.strip().casefold()
            amt_str = line.get("amount") or "0.00"
            seen_semantic_items[semantic_key] = seen_semantic_items.get(semantic_key, 0) + 1
            if seen_semantic_items[semantic_key] > 1:
                line["is_duplicate"] = True
                line["challenge"] = {
                    "is_challenge": True,
                    "level": "high",
                    "justified_amount": "0.00",
                    "challenge_amount": amt_str,
                    "reason": f"Duplicate line item billed multiple times on invoice ({desc}). Challenge to recover duplicate charge.",
                    "is_duplicate": True,
                }
            else:
                line["is_duplicate"] = False
        else:
            line["is_duplicate"] = False
    assessment = data.assessment_by_invoice.get(invoice.id)
    challenges = [line for line in lines if line["challenge"]["is_challenge"]]
    total = sum(
        (Decimal(line["challenge"]["challenge_amount"]) for line in challenges), Decimal("0")
    )
    vehicle = invoice.vehicle
    return {
        "invoice": {
            "id": invoice.id,
            "invoice_number": invoice.invoice_number,
            "vehicle_make": vehicle.make if vehicle else None,
            "vehicle_model": vehicle.model if vehicle else None,
            "vehicle_category": category.category,
            "vehicle_category_source": category.source,
            "registration": vehicle.registration if vehicle else None,
            "paired_assessment_number": assessment.assessment_number if assessment else None,
            "intake_group": _intake_group(invoice),
        },
        "live_invoices": [
            {
                "id": row.id,
                "invoice_number": row.invoice_number,
                "registration": row.vehicle.registration if row.vehicle else None,
            }
            for row in live
        ],
        "threshold_pct": _threshold_text(threshold),
        "minimum_challenge_amount": _text(DEFAULT_POLICY.minimum_challenge_amount),
        "lines": lines,
        "section_breakdowns": [
            {"invoice_id": invoice.id, "invoice_number": invoice.invoice_number, **breakdown}
            for breakdown in _breakdowns(session, data, invoice)
        ],
        "totals": {
            "line_count": len(lines),
            "challenge_count": len(challenges),
            "by_level": {
                level: sum(1 for line in lines if line["challenge"]["level"] == level)
                for level in ("high", "medium", "low")
            },
            "total_challenge_amount": _text(total),
        },
    }


# ---------------------------------------------------------------------------
# POST /claims/{ref}/challenge-email
# ---------------------------------------------------------------------------

#: Keys whose values are money in an analysis payload -- the only figures an
#: email may quote.
_MONEY_KEYS = frozenset(
    {
        "amount",
        "p90",
        "difference",
        "justified_amount",
        "challenge_amount",
        "total_challenge_amount",
        "minimum_challenge_amount",
        "invoice_total",
        "assessment_total",
        "rows_total",
        "total_net",
        "unit_price_net",
    }
)
_MONEY_PATTERN = re.compile(r"£\s?(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d{1,2}))?")


def money_figures_in_text(text: str) -> set[Decimal]:
    """Every £ figure in ``text``, normalised to pence."""

    figures = set()
    for whole, pence in _MONEY_PATTERN.findall(text or ""):
        figures.add(_money(Decimal(f"{whole.replace(',', '')}.{pence or '0'}")))
    return figures


def analysis_money_figures(analysis: Any) -> set[Decimal]:
    """Every money figure an analysis payload contains, at any depth."""

    figures: set[Decimal] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in _MONEY_KEYS and isinstance(item, (str, int, float, Decimal)):
                    try:
                        figures.add(_money(Decimal(str(item))))
                    except ArithmeticError:
                        pass
                else:
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(analysis)
    return figures


def _origin_label(origin: str) -> str:
    return "engineer assessment" if origin == ORIGIN_ASSESSMENT else "invoice"


def _build_challenge_table(lines: list[dict[str, Any]]) -> str:
    headers = ["Line", "Repair Item", "Invoiced", "Benchmark Sources (P90)", "Justified Rate", "Challenge Amount"]
    rows = []
    total_chall = Decimal("0")
    for idx, line in enumerate(lines, 1):
        desc = line.get("description") or line.get("repair_item") or ""
        amt = _gbp(line.get("amount")) if line.get("amount") else "—"
        
        benchmarks = line.get("benchmarks", {})
        sources = []
        tp = benchmarks.get("third_party")
        if tp and tp.get("available") and tp.get("p90"):
            sources.append(f"3rd-Party: {_gbp(tp['p90'])} (n={tp.get('observations', 0)})")
        ih = benchmarks.get("aviva_dlg")
        if ih and ih.get("available") and ih.get("p90"):
            sources.append(f"In-House: {_gbp(ih['p90'])} (n={ih.get('observations', 0)})")
        si = benchmarks.get("same_insurer")
        if si and si.get("available") and si.get("p90"):
            sources.append(f"Same-Insurer: {_gbp(si['p90'])} (n={si.get('observations', 0)})")
        strat = benchmarks.get("strategy_threshold")
        if strat and strat.get("available") and strat.get("p90"):
            sources.append(f"Policy Cap: {_gbp(strat['p90'])}")
            
        src_str = "; ".join(sources) if sources else "Peer benchmark"
        just = _gbp(line["challenge"]["justified_amount"]) if line.get("challenge", {}).get("justified_amount") else "—"
        chall_val = line.get("challenge", {}).get("challenge_amount")
        chall_str = _gbp(chall_val) if chall_val else "—"
        if chall_val:
            try:
                total_chall += Decimal(str(chall_val))
            except Exception:
                pass
        rows.append([f"{idx}.", desc, amt, src_str, just, chall_str])

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))
    col_widths = [w + 2 for w in col_widths]

    def fmt_row(cells: list[str]) -> str:
        parts = []
        for i, c in enumerate(cells):
            if i in (2, 4, 5):
                parts.append(c.rjust(col_widths[i] - 1) + " ")
            else:
                parts.append(c.ljust(col_widths[i]))
        return "".join(parts).rstrip()

    divider = "-" * sum(col_widths)
    header_str = fmt_row(headers)
    row_strings = [fmt_row(r) for r in rows]
    total_row = fmt_row(["", "TOTAL CHALLENGE AMOUNT:", "", "", "", _gbp(total_chall)])

    table_lines = [
        header_str,
        divider,
        *row_strings,
        divider,
        total_row,
    ]
    return "\n".join(table_lines)


def _build_challenge_html_table(lines: list[dict[str, Any]]) -> str:
    rows_html = []
    total_chall = Decimal("0")
    for idx, line in enumerate(lines, 1):
        desc = line.get("description") or line.get("repair_item") or ""
        amt = _gbp(line.get("amount")) if line.get("amount") else "—"
        benchmarks = line.get("benchmarks", {})
        tp = benchmarks.get("third_party")
        tp_str = f"{_gbp(tp['p90'])} <span style='color:#64748b;font-size:11px;'>(n={tp.get('observations', 0)})</span>" if tp and tp.get("available") and tp.get("p90") else "—"
        ih = benchmarks.get("aviva_dlg")
        ih_str = f"{_gbp(ih['p90'])} <span style='color:#64748b;font-size:11px;'>(n={ih.get('observations', 0)})</span>" if ih and ih.get("available") and ih.get("p90") else "—"
        si = benchmarks.get("same_insurer")
        si_str = f"{_gbp(si['p90'])} <span style='color:#64748b;font-size:11px;'>(n={si.get('observations', 0)})</span>" if si and si.get("available") and si.get("p90") else "—"
        just = _gbp(line["challenge"]["justified_amount"]) if line.get("challenge", {}).get("justified_amount") else "—"
        chall_val = line.get("challenge", {}).get("challenge_amount")
        chall_str = _gbp(chall_val) if chall_val else "—"
        if chall_val:
            try:
                total_chall += Decimal(str(chall_val))
            except Exception:
                pass
        
        bg = "#ffffff" if idx % 2 == 1 else "#f8fafc"
        rows_html.append(
            f"<tr style='background-color:{bg};border-bottom:1px solid #e2e8f0;'>"
            f"<td style='padding:10px 12px;text-align:center;'>{idx}</td>"
            f"<td style='padding:10px 12px;font-weight:600;'>{desc}</td>"
            f"<td style='padding:10px 12px;text-align:right;'>{amt}</td>"
            f"<td style='padding:10px 12px;text-align:center;'>{tp_str}</td>"
            f"<td style='padding:10px 12px;text-align:center;'>{ih_str}</td>"
            f"<td style='padding:10px 12px;text-align:center;'>{si_str}</td>"
            f"<td style='padding:10px 12px;text-align:right;font-weight:600;color:#059669;'>{just}</td>"
            f"<td style='padding:10px 12px;text-align:right;font-weight:700;color:#dc2626;'>{chall_str}</td>"
            f"</tr>"
        )
    
    rows_str = "\n".join(rows_html)
    return (
        f"<table style='width:100%;border-collapse:collapse;margin:16px 0;font-size:13px;font-family:Arial,sans-serif;border:1px solid #cbd5e1;'>"
        f"<thead>"
        f"<tr style='background-color:#0f172a;color:#ffffff;text-align:left;'>"
        f"<th style='padding:10px 12px;width:30px;text-align:center;'>#</th>"
        f"<th style='padding:10px 12px;'>Repair Item</th>"
        f"<th style='padding:10px 12px;text-align:right;'>Invoiced</th>"
        f"<th style='padding:10px 12px;text-align:center;'>3rd-Party P90</th>"
        f"<th style='padding:10px 12px;text-align:center;'>In-House P90</th>"
        f"<th style='padding:10px 12px;text-align:center;'>Same-Insurer P90</th>"
        f"<th style='padding:10px 12px;text-align:right;'>Justified Rate</th>"
        f"<th style='padding:10px 12px;text-align:right;'>Challenge Amount</th>"
        f"</tr>"
        f"</thead>"
        f"<tbody>"
        f"{rows_str}"
        f"</tbody>"
        f"<tfoot>"
        f"<tr style='background-color:#f1f5f9;font-weight:700;border-top:2px solid #94a3b8;'>"
        f"<td colspan='7' style='padding:12px;text-align:right;'>TOTAL CHALLENGE AMOUNT:</td>"
        f"<td style='padding:12px;text-align:right;color:#dc2626;font-size:14px;'>{_gbp(total_chall)}</td>"
        f"</tr>"
        f"</tfoot>"
        f"</table>"
    )


def _figures_list(lines: list[dict[str, Any]], rationales: dict[str, str]) -> str:
    table = _build_challenge_table(lines)
    items = []
    for index, line in enumerate(lines, 1):
        challenge = line["challenge"]
        benchmarks = line.get("benchmarks", {})
        
        obs_lines = []
        tp = benchmarks.get("third_party")
        if tp and tp.get("available") and tp.get("p90"):
            obs_lines.append(f"  • Insurer Third-Party P90 : {_gbp(tp['p90'])} (n={tp.get('observations', 0)})")
            
        ih = benchmarks.get("aviva_dlg")
        if ih and ih.get("available") and ih.get("p90"):
            obs_lines.append(f"  • In-House Benchmark P90  : {_gbp(ih['p90'])} (n={ih.get('observations', 0)})")
            
        si = benchmarks.get("same_insurer")
        if si and si.get("available") and si.get("p90"):
            obs_lines.append(f"  • Same-Insurer P90        : {_gbp(si['p90'])} (n={si.get('observations', 0)})")
            
        strat = benchmarks.get("strategy_threshold")
        if strat and strat.get("available") and strat.get("p90"):
            obs_lines.append(f"  • Policy Strategy Cap     : {_gbp(strat['p90'])} ({strat.get('item_name', 'Policy cap')})")

        obs_text = "\n".join(obs_lines) if obs_lines else "  • Verified peer benchmark observation data"
        
        item_text = (
            f"{index}. {line['description']} ({line['repair_item']}, from the {_origin_label(line['origin'])})\n"
            f"   - Invoiced Amount   : {_gbp(line['amount'])}\n"
            f"   - Justified Figure  : {_gbp(challenge['justified_amount'])}\n"
            f"   - Amount Challenged : {_gbp(challenge['challenge_amount'])}\n"
            f"   - Benchmark Observations:\n{obs_text}\n"
            f"   - Challenge Rationale: {challenge['reason']}"
        )
        if rationales.get(line["line_id"]):
            item_text += f"\n   - Handler Rationale : {rationales[line['line_id']].strip()}"
        items.append(item_text)

    item_breakdown = "\n\n".join(items)
    return (
        f"Benchmark Comparison Table:\n\n"
        f"{table}\n\n"
        f"Itemised Challenge Breakdown & Rationale:\n\n"
        f"{item_breakdown}"
    )


def _reference_line(invoice: dict[str, Any]) -> str:
    parts = [f"Repair Invoice {invoice.get('invoice_number') or invoice.get('id')}"]
    vehicle = " ".join(
        value for value in (invoice.get("vehicle_make"), invoice.get("vehicle_model")) if value
    )
    if vehicle:
        parts.append(f"Vehicle: {vehicle}")
    if invoice.get("registration"):
        parts.append(f"Registration: {invoice['registration']}")
    return "Re: " + " | ".join(parts)


def _template(
    analysis: dict[str, Any], lines: list[dict[str, Any]], total: Decimal, recipient: str | None
) -> tuple[str, str]:
    invoice = analysis["invoice"]
    count = len(lines)
    inv_ref = invoice.get('invoice_number') or invoice.get('id')
    vehicle = " ".join(
        value for value in (invoice.get("vehicle_make"), invoice.get("vehicle_model")) if value
    )
    reg = invoice.get("registration") or "—"
    category = invoice.get("vehicle_category") or "Unknown"

    subject = (
        f"Repair Invoice Challenge: Invoice {inv_ref} "
        f"({reg}) – Total Challenged: {_gbp(total)}"
    )

    salutation = f"Dear {recipient or 'Sir or Madam'},"

    reference_line = f"RE: REPAIR INVOICE CHALLENGE – INVOICE {inv_ref}"
    if vehicle:
        reference_line += f" | Vehicle: {vehicle}"
    reference_line += f" | Reg: {reg} | Category: {category}"

    intro = (
        f"We are writing to formally challenge specific charges on repair invoice {inv_ref} "
        f"submitted for the repair of the above vehicle.\n\n"
        f"Following our engineering review and benchmark analysis against market data for "
        f"{category} vehicles, we have identified billed charges that exceed justified peer rates "
        f"or agreed policy terms. We are here to challenge these items, representing a total "
        f"challenge amount of {_gbp(total)} across {count} line item{'s' if count != 1 else ''}."
    )

    table_and_items = _figures_list(lines, {})

    next_steps = (
        f"Next Steps & Settlement Request:\n\n"
        f"We request that you review the above challenge items and confirm acceptance by issuing an amended "
        f"invoice or credit note reflecting the total challenge deduction of {_gbp(total)}.\n\n"
        f"Should you possess supporting commercial documentation, purchase invoices, or manufacturer repair "
        f"methods justifying the originally invoiced amounts, please forward these to us within 5 business days "
        f"for our review.\n\n"
        f"Thank you for your cooperation."
    )

    signoff = "Yours sincerely,\n\nMotor Engineering & Claims Audit Team\nClaimGuard Intelligence"

    body = f"{salutation}\n\n{reference_line}\n\n{intro}\n\n{table_and_items}\n\n{next_steps}\n\n{signoff}"
    return subject, body


def _template_html(
    analysis: dict[str, Any], lines: list[dict[str, Any]], total: Decimal, recipient: str | None
) -> str:
    invoice = analysis["invoice"]
    inv_ref = invoice.get('invoice_number') or invoice.get('id')
    vehicle = " ".join(
        value for value in (invoice.get("vehicle_make"), invoice.get("vehicle_model")) if value
    )
    reg = invoice.get("registration") or "—"
    category = invoice.get("vehicle_category") or "Unknown"

    table_html = _build_challenge_html_table(lines)

    items_html = []
    for idx, line in enumerate(lines, 1):
        challenge = line["challenge"]
        benchmarks = line.get("benchmarks", {})
        tp = benchmarks.get("third_party")
        ih = benchmarks.get("aviva_dlg")
        si = benchmarks.get("same_insurer")
        strat = benchmarks.get("strategy_threshold")

        obs_items = []
        if tp and tp.get("available") and tp.get("p90"):
            obs_items.append(f"<li><strong>3rd-Party P90:</strong> {_gbp(tp['p90'])} (n={tp.get('observations', 0)})</li>")
        if ih and ih.get("available") and ih.get("p90"):
            obs_items.append(f"<li><strong>In-House P90:</strong> {_gbp(ih['p90'])} (n={ih.get('observations', 0)})</li>")
        if si and si.get("available") and si.get("p90"):
            obs_items.append(f"<li><strong>Same-Insurer P90:</strong> {_gbp(si['p90'])} (n={si.get('observations', 0)})</li>")
        if strat and strat.get("available") and strat.get("p90"):
            obs_items.append(f"<li><strong>Policy Strategy Cap:</strong> {_gbp(strat['p90'])} ({strat.get('item_name', 'Policy cap')})</li>")

        obs_ul = "".join(obs_items) if obs_items else "<li>Verified peer benchmark observation data</li>"

        items_html.append(
            f"<div style='margin-bottom:16px;padding:14px 16px;border:1px solid #e2e8f0;border-radius:6px;background-color:#ffffff;'>"
            f"<div style='display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #f1f5f9;padding-bottom:8px;margin-bottom:10px;'>"
            f"<strong style='font-size:14px;color:#0f172a;'>{idx}. {line['description']} ({line['repair_item']})</strong>"
            f"<span style='background-color:#fee2e2;color:#991b1b;padding:3px 10px;border-radius:4px;font-weight:700;font-size:12px;'>Challenged: {_gbp(challenge['challenge_amount'])}</span>"
            f"</div>"
            f"<p style='margin:4px 0 8px 0;font-size:13px;color:#334155;'>"
            f"<strong>Invoiced Amount:</strong> {_gbp(line['amount'])} &nbsp;|&nbsp; "
            f"<strong>Justified Benchmark Figure:</strong> <span style='color:#059669;font-weight:600;'>{_gbp(challenge['justified_amount'])}</span>"
            f"</p>"
            f"<div style='font-size:12px;color:#475569;margin:8px 0;'>"
            f"<strong>Benchmark Observations:</strong>"
            f"<ul style='margin:4px 0 8px 20px;padding:0;'>{obs_ul}</ul>"
            f"</div>"
            f"<p style='margin:8px 0 0 0;font-size:12px;color:#1e293b;background-color:#f8fafc;padding:8px 10px;border-left:3px solid #0284c7;border-radius:2px;'>"
            f"<strong>Challenge Rationale:</strong> {challenge['reason']}"
            f"</p>"
            f"</div>"
        )

    items_block = "\n".join(items_html)

    return f"""<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1e293b;line-height:1.6;max-width:760px;margin:0 auto;padding:20px;background-color:#ffffff;">
  <div style="border-bottom:2px solid #0f172a;padding-bottom:12px;margin-bottom:20px;">
    <h2 style="margin:0 0 4px 0;color:#0f172a;font-size:18px;letter-spacing:-0.02em;">REPAIR INVOICE CHALLENGE NOTICE</h2>
    <p style="margin:0;color:#64748b;font-size:13px;">Motor Engineering &amp; Claims Audit Team</p>
  </div>

  <p style="margin:0 0 14px 0;font-size:14px;">Dear {recipient or 'Sir or Madam'},</p>

  <div style="background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:12px 16px;margin-bottom:18px;font-size:13px;">
    <table style="width:100%;border-collapse:collapse;">
      <tr>
        <td style="padding:4px 0;color:#64748b;width:140px;">Invoice Reference:</td>
        <td style="padding:4px 0;font-weight:600;color:#0f172a;">{inv_ref}</td>
        <td style="padding:4px 0;color:#64748b;width:140px;">Vehicle Category:</td>
        <td style="padding:4px 0;font-weight:600;color:#0f172a;">{category}</td>
      </tr>
      <tr>
        <td style="padding:4px 0;color:#64748b;">Vehicle:</td>
        <td style="padding:4px 0;font-weight:600;color:#0f172a;">{vehicle} ({reg})</td>
        <td style="padding:4px 0;color:#64748b;">Total Challenged:</td>
        <td style="padding:4px 0;font-weight:700;color:#dc2626;font-size:15px;">{_gbp(total)}</td>
      </tr>
    </table>
  </div>

  <p style="font-size:13px;margin-bottom:14px;color:#334155;">
    We are writing to formally challenge specific charges on repair invoice <strong>{inv_ref}</strong> submitted for the repair of the above vehicle.
    Following our engineering review and benchmark analysis against market data for <strong>{category}</strong> vehicles, we have identified billed charges that exceed justified peer market rates or agreed policy terms. We are here to challenge these items, representing a <strong>total challenge amount of {_gbp(total)}</strong>.
  </p>

  <h3 style="font-size:14px;color:#0f172a;margin:20px 0 10px 0;border-bottom:1px solid #e2e8f0;padding-bottom:6px;">1. Benchmark Comparison Table</h3>
  {table_html}

  <h3 style="font-size:14px;color:#0f172a;margin:24px 0 10px 0;border-bottom:1px solid #e2e8f0;padding-bottom:6px;">2. Itemised Challenge Details &amp; Rationale</h3>
  {items_block}

  <div style="background-color:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:14px;margin:24px 0 18px 0;font-size:13px;">
    <strong style="color:#1e40af;font-size:14px;">Next Steps &amp; Settlement Request</strong>
    <p style="margin:6px 0 0 0;color:#1e3a8a;line-height:1.5;">
      We request that you review the above challenge items and confirm acceptance by issuing an amended invoice or credit note reflecting the total challenge deduction of <strong>{_gbp(total)}</strong>.
      If you have supplementary documentation or commercial purchase evidence supporting the original invoiced figures, please forward these to us within 5 business days for our review.
    </p>
  </div>

  <p style="margin:20px 0 0 0;font-size:13px;color:#475569;">
    Yours sincerely,<br /><br />
    <strong>Motor Engineering &amp; Claims Audit Team</strong><br />
    ClaimGuard Intelligence
  </p>
</div>"""


def compose_challenge_email(
    analysis: dict[str, Any],
    selected_lines: list[dict[str, Any]],
    *,
    recipient: str | None,
    writer: Any,
) -> dict[str, Any]:
    """The draft for the selected lines.  Never sends anything.

    The figures list is assembled here, deterministically.  A configured
    writer may supply the subject, opening, closing and one rationale per
    line; if any of that text quotes a £ figure the analysis does not contain,
    the whole AI draft is discarded for the template.  The one derived figure
    is the total of the selected lines, which the template also quotes.
    """

    total = sum(
        (Decimal(line["challenge"]["challenge_amount"]) for line in selected_lines),
        Decimal("0"),
    )
    allowed = analysis_money_figures(analysis) | {_money(total)}
    subject, body = _template(analysis, selected_lines, total, recipient)
    html_body = _template_html(analysis, selected_lines, total, recipient)
    generated_by = "template"

    if writer is not None:
        payload = {
            "invoice": analysis["invoice"],
            "recipient": recipient,
            "pricing_method": "Blended average of available benchmark P90s (Third-party, In-house, Same insurer)",
            "threshold_pct": analysis["threshold_pct"],
            "minimum_challenge_amount": analysis["minimum_challenge_amount"],
            "total_challenge_amount": _text(total),
            "lines": [
                {
                    "line_id": line["line_id"],
                    "description": line["description"],
                    "repair_item": line["repair_item"],
                    "origin": line["origin"],
                    "amount": line["amount"],
                    "level": line["challenge"]["level"],
                    "justified_amount": line["challenge"]["justified_amount"],
                    "challenge_amount": line["challenge"]["challenge_amount"],
                    "reason": line["challenge"]["reason"],
                }
                for line in selected_lines
            ],
        }
        try:
            prose = writer.write(payload)
            selected_ids = {line["line_id"] for line in selected_lines}
            rationales = {
                str(item["line_id"]): str(item["rationale"])
                for item in prose.get("rationales") or []
                if str(item.get("line_id")) in selected_ids
            }
            texts = [
                str(prose["subject"]),
                str(prose["opening"]),
                str(prose["closing"]),
                *rationales.values(),
            ]
            if all(money_figures_in_text(text) <= allowed for text in texts):
                subject = str(prose["subject"]).strip()
                body = "\n\n".join(
                    [
                        f"Dear {recipient or 'Sir or Madam'},",
                        _reference_line(analysis["invoice"]),
                        str(prose["opening"]).strip(),
                        _figures_list(selected_lines, rationales),
                        f"Total challenged: {_gbp(total)}.",
                        str(prose["closing"]).strip(),
                        "Kind regards,\nClaims handler",
                    ]
                )
                generated_by = "ai"
        except Exception:  # noqa: BLE001 - any AI failure means the template
            pass

    return {
        "subject": subject,
        "body": body,
        "html_body": html_body,
        "generated_by": generated_by,
        "lines": selected_lines,
        "total_challenge_amount": _text(total),
    }


def build_challenge_email_writer() -> Any:
    """The configured writer, or ``None`` -- the normal state on a client machine."""

    return benchmark_writing.build_challenge_email_writer(get_settings())


def draft_challenge_email(
    session: Session,
    case_reference: str,
    *,
    invoice_id: str,
    line_ids: Iterable[str],
    recipient: str | None,
    actor: str,
    adjustments: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Draft (never send) the email, and record one audit event saying so."""

    requested = list(dict.fromkeys(line_ids))
    analysis = build_benchmark_analysis(session, case_reference, invoice_id=invoice_id)
    by_id = {line["line_id"]: line for line in analysis["lines"]}
    unknown = [line_id for line_id in requested if line_id not in by_id]
    if unknown:
        raise BenchmarkAnalysisError(
            "UNKNOWN_LINE", f"Not lines of this invoice's analysis: {', '.join(unknown)}"
        )
    # Analysis order, not request order: invoice lines first, then assessment.
    selected = [line for line in analysis["lines"] if line["line_id"] in set(requested)]
    
    # Apply any handler adjustments/overrides
    if adjustments:
        adj_by_id = {str(a.get("line_id")): a for a in adjustments if a.get("line_id")}
        for line in selected:
            adj = adj_by_id.get(line["line_id"])
            if adj and adj.get("adjusted_challenge_amount") is not None:
                adj_amt = Decimal(str(adj["adjusted_challenge_amount"]))
                line_amt = Decimal(str(line["amount"])) if line.get("amount") else Decimal("0")
                line["challenge"]["challenge_amount"] = _text(adj_amt)
                line["challenge"]["justified_amount"] = _text(line_amt - adj_amt)
                line["challenge"]["is_challenge"] = adj_amt > 0
                if adj.get("note"):
                    line["challenge"]["reason"] += f" Handler rationale: {adj['note']}"

    unchallenged = [line["line_id"] for line in selected if not line["challenge"]["is_challenge"]]
    if unchallenged:
        raise BenchmarkAnalysisError(
            "LINE_NOT_CHALLENGED",
            f"Selected line is not challenged: {', '.join(unchallenged)}",
            422,
        )

    draft = compose_challenge_email(
        analysis,
        selected,
        recipient=(recipient or "").strip() or None,
        writer=build_challenge_email_writer(),
    )

    case = _case(session, case_reference)
    session.add(
        AuditEvent(
            case_id=case.id,
            processing_run_id=case.current_processing_run_id,
            actor_type=AuditActorType.USER,
            actor_id=actor,
            event_type="CHALLENGE_EMAIL_DRAFTED",
            entity_type="invoice",
            entity_id=analysis["invoice"]["id"],
            before_json=None,
            after_json={
                "subject": draft["subject"],
                "total_challenge_amount": draft["total_challenge_amount"],
            },
            event_payload_json={
                "line_ids": [line["line_id"] for line in selected],
                "levels": {line["line_id"]: line["challenge"]["level"] for line in selected},
                "challenge_amounts": {
                    line["line_id"]: line["challenge"]["challenge_amount"] for line in selected
                },
                "generated_by": draft["generated_by"],
                "recipient": (recipient or "").strip() or None,
                "threshold_pct": analysis["threshold_pct"],
                # A draft only: the server never sends it.
                "sent": False,
            },
        )
    )
    return draft
