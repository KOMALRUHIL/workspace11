"""FastAPI business routes."""
