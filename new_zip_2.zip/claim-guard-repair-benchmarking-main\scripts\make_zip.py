﻿import zipfile
import os

exclude = {'node_modules', '.env', '.venv', '__pycache__', 'output', '.git', '.pytest_cache', 'dist'}
large_sample_pdfs = {'1185790_doc_11857903.pdf', '1646540_doc_16465407.pdf', '1381115_doc_13811151.pdf'}
dest = '../claim-guard-repair-benchmarking.zip'

if os.path.exists(dest):
    os.remove(dest)

with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude]
        for f in files:
            if f in exclude or f.endswith('.pyc') or f == '.env' or f in large_sample_pdfs:
                continue
            fp = os.path.join(root, f)
            zf.write(fp, arcname=fp)

print('Clean zip created successfully. Size (MB):', round(os.path.getsize(dest) / 1024 / 1024, 2))
