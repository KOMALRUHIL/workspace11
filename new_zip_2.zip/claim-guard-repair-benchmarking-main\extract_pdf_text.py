#!/usr/bin/env python3
import sys
import os
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("PyMuPDF is not installed. Please install it by running: pip install pymupdf")
    sys.exit(1)


def extract_text_from_pdf(pdf_path: str, output_txt_path: str = None) -> str:
    path = Path(pdf_path)
    if not path.exists():
        print(f"Error: File not found at: {path.resolve()}")
        return ""

    if path.suffix.lower() != ".pdf":
        print(f"Error: {path.name} is not a PDF file.")
        return ""

    print("=" * 75)
    print(f"Opening PDF: {path.name} ({path.resolve()})")
    print("=" * 75)

    try:
        doc = fitz.open(path)
    except Exception as exc:
        print(f"Failed to open PDF: {exc}")
        return ""

    if doc.needs_pass:
        print("Error: This PDF is password protected / encrypted.")
        doc.close()
        return ""

    total_pages = len(doc)
    print(f"Total Pages Found: {total_pages}\n")

    full_text_output = []
    total_characters = 0
    total_words = 0

    for page_num in range(total_pages):
        page = doc[page_num]
        page_text = page.get_text("text").strip()
        words = page.get_text("words")  # list of (x0, y0, x1, y1, "word", block_no, line_no, word_no)
        
        char_count = len(page_text)
        word_count = len(words)
        total_characters += char_count
        total_words += word_count

        header = f"=== PAGE {page_num + 1} OF {total_pages} (Characters: {char_count}, Words: {word_count}) ==="
        separator = "=" * len(header)

        page_block = f"\n{header}\n\n{page_text}\n\n{separator}\n"
        full_text_output.append(page_block)

        print(header)
        if page_text:
            print(page_text)
        else:
            print("[NOTICE] No digital text detected on this page (Page might be a scanned image or photo).")
        print(separator)
        print()

    doc.close()
    combined_text = "\n".join(full_text_output)

    if output_txt_path is None:
        output_txt_path = path.parent / f"{path.stem}_extracted_text.txt"
    else:
        output_txt_path = Path(output_txt_path)

    try:
        output_txt_path.write_text(combined_text, encoding="utf-8")
        print("=" * 75)
        print("EXTRACTION SUMMARY:")
        print(f" - Total Pages:      {total_pages}")
        print(f" - Total Words:      {total_words}")
        print(f" - Total Characters: {total_characters}")
        print(f" - Saved Output To:  {output_txt_path.resolve()}")
        print("=" * 75)
    except Exception as exc:
        print(f"Warning: Could not save text file to disk: {exc}")

    return combined_text


def main():
    if len(sys.argv) > 1:
        pdf_file = sys.argv[1]
    else:
        print("Enter the full path to your PDF file:")
        user_input = input("> ").strip().strip('"').strip("'")
        if user_input:
            pdf_file = user_input
        else:
            print("No PDF path provided.")
            sys.exit(1)

    extract_text_from_pdf(pdf_file)


if __name__ == "__main__":
    main()
