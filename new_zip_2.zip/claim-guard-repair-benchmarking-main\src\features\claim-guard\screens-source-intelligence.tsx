import { useEffect, useState } from "react"

import { Button } from "@/components/ui/button"
import {
  fetchClaimExtracts,
  getApiErrorMessage,
  type ClaimExtractsPayload,
} from "@/lib/api"

import type { IntakeGroup } from "./document-api"
import { ExtractsSection } from "./extracts-section"
import { INTAKE_GROUP_LABELS } from "./source-scope"

/** Source-scoped extracted invoice and engineer assessment evidence. */
export function SourceIntelligenceScreen({
  caseReference,
  intakeGroup,
  onOpenBenchmarks,
}: {
  caseReference: string
  intakeGroup: IntakeGroup
  finalised?: boolean
  onApproved?: () => Promise<void> | void
  /** Benchmark computation for a reference source; Benchmark analysis for
   * the new invoice. */
  onOpenBenchmarks: () => void
}) {
  const [extracts, setExtracts] = useState<ClaimExtractsPayload | null>(null)
  const [extractsLoading, setExtractsLoading] = useState(true)
  const [extractsError, setExtractsError] = useState<string | null>(null)
  const label = INTAKE_GROUP_LABELS[intakeGroup]

  useEffect(() => {
    let active = true
    void fetchClaimExtracts(caseReference, intakeGroup)
      .then((payload) => {
        if (!active) return
        setExtracts(payload)
        setExtractsError(null)
      })
      .catch((e) => {
        if (!active) return
        setExtracts(null)
        setExtractsError(getApiErrorMessage(e))
      })
      .finally(() => {
        if (active) setExtractsLoading(false)
      })
    return () => {
      active = false
    }
  }, [caseReference, intakeGroup])

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-card px-4 py-3">
        <div>
          <p className="text-sm font-medium">{label}</p>
          <p className="text-xs text-muted-foreground">
            Document intelligence · extracted invoice and engineer assessment
            details for this source.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={onOpenBenchmarks}>
          {intakeGroup === "live"
            ? "Go to Benchmark analysis"
            : "Go to Benchmark computation"}
        </Button>
      </div>

      <ExtractsSection
        extracts={extracts}
        loading={extractsLoading}
        error={extractsError}
        scopeLabel={label}
      />
    </>
  )
}
